import os
import tempfile
import time
from collections import deque
from dataclasses import dataclass
from typing import Callable

import numpy as np
import sounddevice as sd
from faster_whisper import WhisperModel
from scipy.io.wavfile import write

from config.voice_config import (
    LISTEN_POLL_INTERVAL,
    MAX_RECORDING_DURATION,
    MIN_RECORDING_DURATION,
    MIN_VOICED_DURATION,
    PRE_SPEECH_ROLLBACK,
    PRE_SPEECH_TIMEOUT,
    SAMPLE_RATE,
    SILENCE_DURATION,
    SILENCE_THRESHOLD,
    STT_LANGUAGE,
    STT_MODEL_SIZE,
)


VIRTUAL_DEVICE_KEYWORDS = (
    "voicemod",
    "mapeador",
    "mapper",
    "dummy",
    "line out",
    "wave speaker",
    "stereo mix",
)

LISTEN_STATUS_IDLE = "idle"
LISTEN_STATUS_NO_SPEECH = "no_speech"
LISTEN_STATUS_TOO_SHORT = "too_short"
LISTEN_STATUS_TRANSCRIBING = "transcribing"
LISTEN_STATUS_TRANSCRIBED = "transcribed"
LISTEN_STATUS_EMPTY_TRANSCRIPT = "empty_transcript"
LISTEN_STATUS_ERROR = "error"


@dataclass
class ListenResult:
    text: str = ""
    status: str = LISTEN_STATUS_IDLE
    message: str = ""
    audio_duration: float = 0.0
    voiced_duration: float = 0.0


class SpeechCaptureSession:
    def __init__(
        self,
        samplerate: int,
        silence_threshold: float,
        silence_duration: float,
        max_duration: float,
        min_recording_duration: float,
        pre_speech_timeout: float,
        min_voiced_duration: float = MIN_VOICED_DURATION,
        pre_speech_rollback: float = PRE_SPEECH_ROLLBACK,
    ):
        self.samplerate = int(samplerate)
        self.silence_threshold = float(silence_threshold)
        self.silence_duration = float(silence_duration)
        self.max_duration = float(max_duration)
        self.min_recording_duration = float(min_recording_duration)
        self.pre_speech_timeout = float(pre_speech_timeout)
        self.min_voiced_duration = float(min_voiced_duration)
        self.pre_speech_rollback = float(pre_speech_rollback)

        self.capture_start = time.monotonic()
        self.speech_started = False
        self.speech_start = None
        self.silence_start = None
        self.audio_duration = 0.0
        self.voiced_duration = 0.0
        self.audio_buffer = []
        self._pre_speech_buffer = deque()
        self._pre_speech_duration = 0.0

    def process_audio(self, indata, now: float | None = None) -> float:
        now = now if now is not None else time.monotonic()
        audio = np.asarray(indata).copy()
        chunk_duration = self._chunk_duration(audio)
        volume = self._volume(audio)
        is_voice = volume > self.silence_threshold

        if not self.speech_started:
            self._add_pre_speech(audio, chunk_duration)

            if is_voice:
                self.speech_started = True
                self.speech_start = now
                self.silence_start = None
                self.audio_buffer.extend(chunk for chunk, _duration in self._pre_speech_buffer)
                self.audio_duration = self._pre_speech_duration
                self.voiced_duration += chunk_duration

            return volume

        self.audio_buffer.append(audio)
        self.audio_duration += chunk_duration

        if is_voice:
            self.voiced_duration += chunk_duration
            self.silence_start = None
        elif self.silence_start is None:
            self.silence_start = now

        return volume

    def should_stop(self, now: float | None = None) -> bool:
        now = now if now is not None else time.monotonic()
        elapsed = now - self.capture_start

        if elapsed >= self.max_duration:
            return True

        if not self.speech_started:
            return elapsed >= self.pre_speech_timeout

        if self.audio_duration < self.min_recording_duration:
            return False

        return bool(self.silence_start and (now - self.silence_start) >= self.silence_duration)

    def build_result(self) -> tuple[ListenResult, np.ndarray | None]:
        if not self.speech_started or not self.audio_buffer:
            return ListenResult(
                status=LISTEN_STATUS_NO_SPEECH,
                message="Nenhuma fala detectada.",
            ), None

        if self.voiced_duration < self.min_voiced_duration:
            return ListenResult(
                status=LISTEN_STATUS_TOO_SHORT,
                message="Fala muito curta ou ruído.",
                audio_duration=self.audio_duration,
                voiced_duration=self.voiced_duration,
            ), None

        audio = np.concatenate(self.audio_buffer, axis=0)
        return ListenResult(
            status=LISTEN_STATUS_TRANSCRIBING,
            audio_duration=self.audio_duration,
            voiced_duration=self.voiced_duration,
        ), audio

    def _add_pre_speech(self, audio, duration: float):
        self._pre_speech_buffer.append((audio, duration))
        self._pre_speech_duration += duration

        while self._pre_speech_duration > self.pre_speech_rollback and self._pre_speech_buffer:
            _old_audio, old_duration = self._pre_speech_buffer.popleft()
            self._pre_speech_duration -= old_duration

    def _chunk_duration(self, audio) -> float:
        if audio.ndim == 0:
            return 0.0

        return float(audio.shape[0]) / float(self.samplerate)

    def _volume(self, audio) -> float:
        if audio.size == 0:
            return 0.0

        normalized_audio = audio.astype(np.float32) / np.iinfo(np.int16).max
        return float(np.sqrt(np.mean(normalized_audio ** 2)))


class SpeechToText:
    def __init__(self, model_size=STT_MODEL_SIZE, language=STT_LANGUAGE, device=None):
        self.language = language
        self.device = device
        self.last_error = ""
        self.last_result = ListenResult()
        self.model = WhisperModel(model_size, device="cpu", compute_type="int8")

    def _is_virtual_device(self, device_name: str) -> bool:
        normalized_name = device_name.lower()
        return any(keyword in normalized_name for keyword in VIRTUAL_DEVICE_KEYWORDS)

    def _pick_input_device(self):
        if self.device is not None:
            return self.device

        devices = [
            device
            for device in sd.query_devices()
            if device.get("max_input_channels", 0) > 0
        ]

        if not devices:
            raise RuntimeError("Nenhum microfone disponivel.")

        default_input = None
        default_config = sd.default.device

        if isinstance(default_config, (list, tuple)) and default_config:
            default_input = default_config[0]
        elif isinstance(default_config, int):
            default_input = default_config

        default_device = next(
            (device for device in devices if device.get("index") == default_input),
            None,
        )

        if default_device and not self._is_virtual_device(default_device["name"]):
            return default_device

        preferred_device = next(
            (device for device in devices if not self._is_virtual_device(device["name"])),
            None,
        )

        if preferred_device:
            return preferred_device

        if default_device:
            return default_device

        return devices[0]

    def _resolve_samplerate(self, device, requested_samplerate):
        if requested_samplerate is not None:
            try:
                sd.check_input_settings(
                    device=device,
                    samplerate=requested_samplerate,
                    channels=1,
                    dtype="int16",
                )
                return int(requested_samplerate)
            except Exception:
                pass

        try:
            device_info = sd.query_devices(device)
            fallback_samplerate = int(device_info["default_samplerate"])
            sd.check_input_settings(
                device=device,
                samplerate=fallback_samplerate,
                channels=1,
                dtype="int16",
            )
            return fallback_samplerate
        except Exception as exc:
            raise RuntimeError(
                f"Nao consegui configurar o microfone selecionado: {exc}"
            ) from exc

    def listen(
        self,
        samplerate=SAMPLE_RATE,
        silence_threshold=SILENCE_THRESHOLD,
        silence_duration=SILENCE_DURATION,
        max_duration=MAX_RECORDING_DURATION,
        min_recording_duration=MIN_RECORDING_DURATION,
        duration=None,
        pre_speech_timeout=PRE_SPEECH_TIMEOUT,
        min_voiced_duration=MIN_VOICED_DURATION,
        pre_speech_rollback=PRE_SPEECH_ROLLBACK,
        status_callback: Callable[[str], None] | None = None,
    ):
        if duration is not None:
            max_duration = duration

        result = self.listen_result(
            samplerate=samplerate,
            silence_threshold=silence_threshold,
            silence_duration=silence_duration,
            max_duration=max_duration,
            min_recording_duration=min_recording_duration,
            pre_speech_timeout=pre_speech_timeout,
            min_voiced_duration=min_voiced_duration,
            pre_speech_rollback=pre_speech_rollback,
            status_callback=status_callback,
        )
        return result.text

    def listen_result(
        self,
        samplerate=SAMPLE_RATE,
        silence_threshold=SILENCE_THRESHOLD,
        silence_duration=SILENCE_DURATION,
        max_duration=MAX_RECORDING_DURATION,
        min_recording_duration=MIN_RECORDING_DURATION,
        pre_speech_timeout=PRE_SPEECH_TIMEOUT,
        min_voiced_duration=MIN_VOICED_DURATION,
        pre_speech_rollback=PRE_SPEECH_ROLLBACK,
        status_callback: Callable[[str], None] | None = None,
    ) -> ListenResult:
        self.last_error = ""
        self.last_result = ListenResult(status=LISTEN_STATUS_IDLE)

        try:
            selected_device = self._pick_input_device()
            device_id = (
                selected_device["index"]
                if isinstance(selected_device, dict)
                else selected_device
            )
            device_name = (
                selected_device["name"]
                if isinstance(selected_device, dict)
                else sd.query_devices(selected_device)["name"]
            )
            samplerate = self._resolve_samplerate(device_id, samplerate)
        except Exception as exc:
            return self._finish_result(
                ListenResult(
                    status=LISTEN_STATUS_ERROR,
                    message=f"Falha ao iniciar o microfone: {exc}",
                )
            )

        self._emit_status(status_callback, "listening")
        print(f"Microfone: {device_name}")

        session = SpeechCaptureSession(
            samplerate=samplerate,
            silence_threshold=silence_threshold,
            silence_duration=silence_duration,
            max_duration=max_duration,
            min_recording_duration=min_recording_duration,
            pre_speech_timeout=pre_speech_timeout,
            min_voiced_duration=min_voiced_duration,
            pre_speech_rollback=pre_speech_rollback,
        )

        def callback(indata, frames, callback_time, status):
            if status and not self.last_error:
                self.last_error = f"Captura de audio com aviso: {status}"

            session.process_audio(indata)

        try:
            with sd.InputStream(
                samplerate=samplerate,
                device=device_id,
                channels=1,
                dtype="int16",
                callback=callback,
            ):
                while not session.should_stop():
                    time.sleep(LISTEN_POLL_INTERVAL)
        except Exception as exc:
            return self._finish_result(
                ListenResult(
                    status=LISTEN_STATUS_ERROR,
                    message=f"Falha ao capturar audio: {exc}",
                )
            )

        capture_result, audio = session.build_result()
        if audio is None:
            return self._finish_result(capture_result)

        self._emit_status(status_callback, "transcribing")
        transcript = self._transcribe_audio(audio, samplerate)

        if not transcript:
            if self.last_error:
                return self._finish_result(
                    ListenResult(
                        status=LISTEN_STATUS_ERROR,
                        message=self.last_error,
                        audio_duration=capture_result.audio_duration,
                        voiced_duration=capture_result.voiced_duration,
                    )
                )

            return self._finish_result(
                ListenResult(
                    status=LISTEN_STATUS_EMPTY_TRANSCRIPT,
                    message="Não consegui transcrever uma fala clara.",
                    audio_duration=capture_result.audio_duration,
                    voiced_duration=capture_result.voiced_duration,
                )
            )

        return self._finish_result(
            ListenResult(
                text=transcript,
                status=LISTEN_STATUS_TRANSCRIBED,
                audio_duration=capture_result.audio_duration,
                voiced_duration=capture_result.voiced_duration,
            )
        )

    def _transcribe_audio(self, audio, samplerate: int) -> str:
        audio_path = None

        try:
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as file:
                audio_path = file.name

            write(audio_path, samplerate, audio)

            segments, _ = self.model.transcribe(
                audio_path,
                language=self.language,
                vad_filter=True,
            )

            return " ".join(segment.text.strip() for segment in segments).strip()
        except Exception as exc:
            self.last_error = f"Falha ao transcrever audio: {exc}"
            return ""
        finally:
            if audio_path and os.path.exists(audio_path):
                os.remove(audio_path)

    def _finish_result(self, result: ListenResult) -> ListenResult:
        if result.status == LISTEN_STATUS_ERROR:
            self.last_error = result.message

        self.last_result = result
        return result

    def _emit_status(self, callback: Callable[[str], None] | None, status: str):
        if callback is None:
            return

        try:
            callback(status)
        except Exception as exc:
            print("Erro no callback de voz:", repr(exc))
