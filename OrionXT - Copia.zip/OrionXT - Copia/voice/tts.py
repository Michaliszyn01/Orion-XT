import asyncio
import ctypes
import os
import queue
import re
import tempfile
import threading

from core.interrupt_controller import interrupt_controller

try:
    import edge_tts
except ImportError:
    edge_tts = None


VOICE = "pt-BR-AntonioNeural"
MAX_SPEECH_CHARS = 400

_speech_queue = queue.Queue()
_speaking = False
_worker_started = False
_state_lock = threading.RLock()
_speech_generation = 0
_current_alias = ""


def clean_text(text: str) -> str:
    text = text.replace("**", "")
    text = text.replace("*", "")
    text = text.replace("\n", ". ")
    return text.strip()


def split_text_for_tts(text: str, max_chars: int = 450) -> list[str]:
    text = clean_text(text)

    if not text:
        return []

    if len(text) <= max_chars:
        return [text]

    sentences = [
        sentence.strip()
        for sentence in re.split(r"(?<=[.!?;])\s+", text)
        if sentence.strip()
    ]

    chunks = []
    current = ""

    for sentence in sentences:
        if len(sentence) > max_chars:
            if current:
                chunks.append(current)
                current = ""

            chunks.extend(_split_long_sentence(sentence, max_chars))
            continue

        candidate = f"{current} {sentence}".strip()

        if len(candidate) <= max_chars:
            current = candidate
        else:
            if current:
                chunks.append(current)
            current = sentence

    if current:
        chunks.append(current)

    return chunks


def _split_long_sentence(sentence: str, max_chars: int) -> list[str]:
    words = sentence.split()
    chunks = []
    current = ""

    for word in words:
        if len(word) > max_chars:
            if current:
                chunks.append(current)
                current = ""

            chunks.extend(
                word[index:index + max_chars]
                for index in range(0, len(word), max_chars)
            )
            continue

        candidate = f"{current} {word}".strip()

        if len(candidate) <= max_chars:
            current = candidate
        else:
            if current:
                chunks.append(current)
            current = word

    if current:
        chunks.append(current)

    return chunks


def _mci(command: str):
    error = ctypes.windll.winmm.mciSendStringW(command, None, 0, None)

    if error:
        buffer = ctypes.create_unicode_buffer(255)
        ctypes.windll.winmm.mciGetErrorStringW(error, buffer, 255)
        raise RuntimeError(f"MCI erro {error}: {buffer.value}")


def _safe_mci(command: str) -> bool:
    try:
        _mci(command)
        return True
    except Exception:
        return False


def _is_current_generation(generation: int) -> bool:
    with _state_lock:
        return generation == _speech_generation


def _next_generation() -> int:
    global _speech_generation

    with _state_lock:
        _speech_generation += 1
        return _speech_generation


def _invalidate_current_speech() -> int:
    return _next_generation()


def _set_current_alias(alias: str):
    global _current_alias

    with _state_lock:
        _current_alias = alias


def _clear_current_alias(alias: str):
    global _current_alias

    with _state_lock:
        if _current_alias == alias:
            _current_alias = ""


def _stop_current_speech() -> bool:
    with _state_lock:
        alias = _current_alias

    if not alias:
        return False

    stopped = _safe_mci(f"stop {alias}")
    closed = _safe_mci(f"close {alias}")
    _clear_current_alias(alias)
    return stopped or closed


def _clear_speech_queue() -> int:
    _invalidate_current_speech()
    cleared = 0

    while True:
        try:
            _speech_queue.get_nowait()
        except queue.Empty:
            break

        cleared += 1
        _speech_queue.task_done()

    return cleared


def _play_mp3(filename: str, generation: int):
    alias = "orion_tts"

    if interrupt_controller.is_interrupted() or not _is_current_generation(generation):
        return

    _safe_mci(f"close {alias}")
    _mci(f'open "{filename}" type mpegvideo alias {alias}')
    _set_current_alias(alias)

    try:
        if interrupt_controller.is_interrupted() or not _is_current_generation(generation):
            return

        try:
            _mci(f"play {alias} wait")
        except RuntimeError:
            if interrupt_controller.is_interrupted() or not _is_current_generation(generation):
                return
            raise
    finally:
        _safe_mci(f"close {alias}")
        _clear_current_alias(alias)


async def _speak(text: str, generation: int):
    text = clean_text(text)

    if not text:
        return

    if edge_tts is None:
        print("Erro no TTS: edge-tts nao esta instalado.")
        return

    filename = ""

    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as file:
            filename = file.name

        communicate = edge_tts.Communicate(text, VOICE)
        await communicate.save(filename)

        if interrupt_controller.is_interrupted() or not _is_current_generation(generation):
            return

        _play_mp3(filename, generation)
    finally:
        if filename and os.path.exists(filename):
            try:
                os.remove(filename)
            except OSError as e:
                print("Erro ao remover audio temporario do TTS:", repr(e))


def is_speaking() -> bool:
    with _state_lock:
        return _speaking or not _speech_queue.empty()


def _speech_worker():
    global _speaking

    while True:
        item = _speech_queue.get()

        if item is None:
            _speech_queue.task_done()
            break

        generation, text = item

        try:
            with _state_lock:
                _speaking = True
            interrupt_controller.set_speaking(True)

            if not interrupt_controller.is_interrupted() and _is_current_generation(generation):
                asyncio.run(_speak(text, generation))
        except Exception as e:
            if not interrupt_controller.is_interrupted():
                print("Erro no TTS:", repr(e))
        finally:
            with _state_lock:
                _speaking = False
            interrupt_controller.set_speaking(False)
            _speech_queue.task_done()


def _ensure_worker():
    global _worker_started

    if _worker_started:
        return

    thread = threading.Thread(target=_speech_worker, daemon=True)
    thread.start()
    _worker_started = True


def speak(text: str):
    text = clean_text(text)

    if not text:
        return

    if is_speaking():
        interrupt_controller.request_interrupt()

    interrupt_controller.clear_interrupt()
    generation = _next_generation()
    _ensure_worker()

    for chunk in split_text_for_tts(text, MAX_SPEECH_CHARS):
        _speech_queue.put((generation, chunk))


def speak_blocking(text: str):
    global _speaking

    text = clean_text(text)

    if not text:
        return

    if is_speaking():
        interrupt_controller.request_interrupt()

    interrupt_controller.clear_interrupt()
    generation = _next_generation()

    try:
        with _state_lock:
            _speaking = True
        interrupt_controller.set_speaking(True)

        for chunk in split_text_for_tts(text, MAX_SPEECH_CHARS):
            try:
                if interrupt_controller.is_interrupted() or not _is_current_generation(generation):
                    break
                asyncio.run(_speak(chunk, generation))
            except Exception as e:
                if not interrupt_controller.is_interrupted():
                    print("Erro no TTS:", repr(e))
    finally:
        with _state_lock:
            _speaking = False
        interrupt_controller.set_speaking(False)


def stop_speech() -> bool:
    return interrupt_controller.request_interrupt()


def clear_speech_queue() -> int:
    return _clear_speech_queue()


interrupt_controller.register_tts_handlers(
    stop_current_speech=_stop_current_speech,
    clear_speech_queue=_clear_speech_queue,
)
