import os
import shutil
from pathlib import Path
from difflib import get_close_matches

from registry.apps import APPS
from registry.websites import WEBSITES
from registry.folders import FOLDERS


def normalize(text: str) -> str:
    return str(text or "").lower().strip()


URI_TARGETS = {"ms-settings:"}


def expand_path(path: str) -> Path | str:
    path = str(path or "").strip()

    if path == "ms-settings:":
        return path

    expanded = os.path.expandvars(path.replace("/", os.sep))
    return Path(expanded)


def find_by_alias(registry: dict, name: str, *, allow_fuzzy: bool = False):
    name = normalize(name)

    if not name:
        return None, None

    if name in registry:
        return name, registry[name]

    alias_map = {}

    for key, data in registry.items():
        alias_map[normalize(key)] = key

        for alias in data.get("aliases", []):
            alias_map[normalize(alias)] = key

    if name in alias_map:
        key = alias_map[name]
        return key, registry[key]

    if not allow_fuzzy:
        return None, None

    # fuzzy matching leve
    matches = get_close_matches(
        name,
        alias_map.keys(),
        n=1,
        cutoff=0.82
    )

    if matches:
        key = alias_map[matches[0]]
        return key, registry[key]

    return None, None


def resolve_app(name: str, *, allow_fuzzy: bool = False):
    return find_by_alias(APPS, name, allow_fuzzy=allow_fuzzy)


def resolve_website(name: str, *, allow_fuzzy: bool = False):
    return find_by_alias(WEBSITES, name, allow_fuzzy=allow_fuzzy)


def resolve_folder(name: str, *, allow_fuzzy: bool = False):
    return find_by_alias(FOLDERS, name, allow_fuzzy=allow_fuzzy)


def _looks_like_path(raw_path: str) -> bool:
    return (
        "/" in raw_path
        or "\\" in raw_path
        or raw_path.startswith(".")
        or raw_path.startswith("%")
        or ":" in raw_path
    )


def first_existing_path(paths: list[str]):
    for raw_path in paths:
        raw_path = str(raw_path or "").strip()

        if not raw_path:
            continue

        path = expand_path(raw_path)

        if isinstance(path, str):
            if path in URI_TARGETS:
                return path
            continue

        if path.exists():
            return path

        if not _looks_like_path(raw_path):
            executable_path = shutil.which(raw_path)
            if executable_path:
                return Path(executable_path)

    return None


def known_website_names():
    names = set()

    for key, data in WEBSITES.items():
        names.add(normalize(key))
        for alias in data.get("aliases", []):
            names.add(normalize(alias))

    return names
