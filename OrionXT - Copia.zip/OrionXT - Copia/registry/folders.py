FOLDERS = {
    "downloads": {
        "aliases": ["downloads", "pasta downloads", "baixados"],
        "paths": [
            "%USERPROFILE%/Downloads",
            "%USERPROFILE%/OneDrive/Downloads",
        ],
    },
    "documentos": {
        "aliases": ["documentos", "documentos pessoais"],
        "paths": [
            "%USERPROFILE%/Documents",
            "%USERPROFILE%/OneDrive/Documents",
        ],
    },
    "desktop": {
        "aliases": ["desktop", "área de trabalho", "area de trabalho"],
        "paths": [
            "%USERPROFILE%/Desktop",
            "%USERPROFILE%/OneDrive/Desktop",
        ],
    },
    "imagens": {
        "aliases": ["imagens", "fotos"],
        "paths": [
            "%USERPROFILE%/Pictures",
            "%USERPROFILE%/OneDrive/Pictures",
        ],
    },
    "vídeos": {
        "aliases": ["vídeos", "videos"],
        "paths": [
            "%USERPROFILE%/Videos",
            "%USERPROFILE%/OneDrive/Videos",
        ],
    },
    "músicas": {
        "aliases": ["músicas", "musicas"],
        "paths": [
            "%USERPROFILE%/Music",
            "%USERPROFILE%/OneDrive/Music",
        ],
    },
    "orionxt": {
        "aliases": ["orionxt", "projeto orionxt", "pasta do orion"],
        "paths": [
            "%USERPROFILE%/OneDrive/Desktop/OrionXT",
            "%USERPROFILE%/Desktop/OrionXT",
        ],
    },
}