WEBSITES = {
    "google": {
        "aliases": ["google"],
        "url": "https://www.google.com",
        "search_url": "https://www.google.com/search?q={query}",
    },
    "youtube": {
        "aliases": ["youtube", "yt"],
        "url": "https://www.youtube.com",
        "search_url": "https://www.youtube.com/results?search_query={query}",
    },
    "gmail": {
        "aliases": ["gmail", "email", "e-mail"],
        "url": "https://mail.google.com",
        "search_url": "https://mail.google.com/mail/u/0/#search/{query}",
    },
    "wikipedia": {
        "aliases": ["wikipedia", "wikipédia"],
        "url": "https://pt.wikipedia.org",
        "search_url": "https://pt.wikipedia.org/w/index.php?search={query}",
    },
    "github": {
        "aliases": ["github", "git hub"],
        "url": "https://github.com",
        "search_url": "https://github.com/search?q={query}",
    },
    "linkedin": {
        "aliases": ["linkedin"],
        "url": "https://www.linkedin.com",
        "search_url": "https://www.linkedin.com/search/results/all/?keywords={query}",
    },
    "chatgpt": {
        "aliases": ["chatgpt", "chat gpt"],
        "url": "https://chat.openai.com",
        "search_url": None,
    },
    "alura": {
        "aliases": ["alura"],
        "url": "https://www.alura.com.br",
        "search_url": "https://www.alura.com.br/busca?query={query}",
    },
    "netflix": {
        "aliases": ["netflix"],
        "url": "https://www.netflix.com",
        "search_url": None,
    },
}