from core.patterns import forbids_action, forbids_search


NO_SEARCH_RESPONSE = (
    "Você tem razão. Não vou pesquisar isso. Vou responder usando apenas o que eu já sei "
    "e o que está salvo na memória."
)

NO_ACTION_RESPONSE = (
    "Você tem razão. Não vou executar essa ação. Vou responder usando apenas o que eu já sei "
    "e o que está salvo na memória."
)


class ConversationGuard:
    """Travas universais antes da interpretação por IA.

    O guard não decide intenção de domínio e não consulta memória. Ele só bloqueia
    ações claramente proibidas pelo usuário.
    """

    def __init__(self, memory_store=None):
        self.memory_store = memory_store

    def handle(self, text: str) -> str | None:
        if forbids_search(text):
            return NO_SEARCH_RESPONSE

        if forbids_action(text):
            return NO_ACTION_RESPONSE

        return None
