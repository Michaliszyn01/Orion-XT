import json
import re

from core.patterns import forbids_action, forbids_search
from core.utils import normalize_text


ALLOWED_INTENTS = {
    "chat",
    "execute_action",
    "search_web",
    "ask_memory",
    "save_memory",
    "update_preference",
    "study_strategy",
    "clarify",
}

ALLOWED_DOMAINS = {
    "general",
    "system",
    "web",
    "app",
    "folder",
    "memory",
    "academic",
    "study",
}

ALLOWED_ACTION_TYPES = {
    "open_app",
    "close_app",
    "open_website",
    "search_website",
    "open_folder",
    "multi_action",
}


class IntentInterpreter:
    def __init__(self, client, memory=None, memory_store=None):
        self.client = client
        self.memory = memory
        self.memory_store = memory_store

    def interpret(self, user_input: str) -> dict:
        prompt = self._build_prompt(user_input)

        try:
            raw = self.client.generate(prompt)
        except Exception as exc:
            print("Erro no IntentInterpreter:", repr(exc))
            return self._safe_default(user_input)

        parsed = self._extract_json(raw)
        if not isinstance(parsed, dict):
            return self._safe_default(user_input)

        normalized = self._normalize_intent(parsed)

        if normalized["confidence"] < 0.55:
            return self._safe_default(user_input)

        if forbids_search(user_input, include_soft=True) and normalized.get("should_search"):
            normalized.update({
                "intent": "chat",
                "domain": "system",
                "should_execute": False,
                "should_search": False,
                "action_type": "",
                "target": "",
                "query": "",
                "answer_hint": "Responder sem pesquisar.",
            })

        if forbids_action(user_input) and normalized.get("should_execute"):
            normalized.update({
                "intent": "chat",
                "domain": "system",
                "should_execute": False,
                "should_search": False,
                "action_type": "",
                "target": "",
                "query": "",
                "answer_hint": "Responder sem executar ação.",
            })

        return normalized

    def _build_prompt(self, user_input: str) -> str:
        memory_name = ""
        if self.memory is not None:
            try:
                memory_name = self.memory.get_name()
            except Exception:
                memory_name = ""

        normalized_input = normalize_text(user_input)

        return f"""
Você é o interpretador de intenção do OrionXT.

Sua função NÃO é responder ao usuário diretamente.
Sua função é interpretar a mensagem e retornar SOMENTE JSON válido.

Você deve identificar:
- se o usuário quer conversar
- se quer executar uma ação
- se quer pesquisar na internet
- se quer consultar memória
- se quer salvar memória
- se quer atualizar preferência
- se quer estratégia de estudo
- se a mensagem está ambígua

Intenções permitidas:
- chat
- execute_action
- search_web
- ask_memory
- save_memory
- update_preference
- study_strategy
- clarify

Domínios permitidos:
- general
- system
- web
- app
- folder
- memory
- academic
- study

Tipos de ação permitidos:
- open_app
- close_app
- open_website
- search_website
- open_folder
- multi_action

Regras principais:
1. Não execute ações apenas porque o usuário mencionou uma ação.
Exemplo: "eles estavam falando sobre abrir o Google, eu não entendi"
→ chat, should_execute=false

2. Execute ação somente quando o usuário pedir claramente.
Exemplo: "abre o Google"
→ execute_action, open_website, target=google, should_execute=true

3. Pesquise somente quando o usuário pedir claramente uma busca na internet.
Exemplo: "pesquisa no YouTube aula de Python"
→ search_web, target=youtube, query="aula de python", should_search=true

4. Se o usuário disser para não pesquisar, nunca pesquisar.
Exemplo: "não é para pesquisar"
→ chat, should_search=false

5. Perguntas factuais gerais devem ser chat, não pesquisa automática.
Exemplo: "qual é a população do Brasil?"
→ chat, should_search=false

6. Se a informação exigir dados atuais e o usuário não pediu pesquisa, use chat e explique limitação.

7. Perguntas sobre dados pessoais salvos devem ser ask_memory.
Exemplo: "qual curso eu quero fazer?"
→ ask_memory, domain=academic, entities={{"memory_key": "target_course"}}

8. Perguntas sobre notas do ENEM salvas devem ser ask_memory.
Exemplo: "quais são minhas notas do ENEM?"
→ ask_memory, domain=academic, entities={{"memory_key": "enem_scores"}}

9. Pedidos de estratégia com base em notas devem ser study_strategy.
Exemplo: "o que eu preciso estudar para melhorar minhas notas?"
→ study_strategy, domain=academic

10. Se o usuário informar objetivo, preferência ou meta, use save_memory ou update_preference.
Exemplo: "meu objetivo é engenharia de software na UFPR, UTFPR ou PUCPR"
→ save_memory, domain=academic

11. Se o usuário autorizar pesquisa automática, update_preference.
Exemplo: "pode pesquisar sem minha ordem"
→ update_preference, entities={{"allow_auto_search": true}}

12. Se estiver ambíguo, use clarify.
Exemplo: "abre isso aí"
→ clarify

13. O JSON deve ser conservador:
- se não tiver certeza, não execute
- se não tiver certeza, não pesquise
- prefira chat ou clarify

Formato obrigatório:
{{
  "intent": "...",
  "domain": "...",
  "confidence": 0.0,
  "should_execute": false,
  "should_search": false,
  "action_type": "",
  "target": "",
  "query": "",
  "entities": {{}},
  "answer_hint": ""
}}

Exemplos:

Usuário: abre o google
JSON:
{{
  "intent": "execute_action",
  "domain": "web",
  "confidence": 0.95,
  "should_execute": true,
  "should_search": false,
  "action_type": "open_website",
  "target": "google",
  "query": "",
  "entities": {{}},
  "answer_hint": "Abrir Google"
}}

Usuário: eles estavam falando sobre abrir o google, eu não entendi
JSON:
{{
  "intent": "chat",
  "domain": "general",
  "confidence": 0.9,
  "should_execute": false,
  "should_search": false,
  "action_type": "",
  "target": "",
  "query": "",
  "entities": {{}},
  "answer_hint": "Explicar o que significa abrir o Google sem executar ação"
}}

Usuário: não é para pesquisar
JSON:
{{
  "intent": "chat",
  "domain": "system",
  "confidence": 0.95,
  "should_execute": false,
  "should_search": false,
  "action_type": "",
  "target": "",
  "query": "",
  "entities": {{}},
  "answer_hint": "Confirmar que não vai pesquisar"
}}

Usuário: pesquisa no youtube aula de python
JSON:
{{
  "intent": "search_web",
  "domain": "web",
  "confidence": 0.95,
  "should_execute": true,
  "should_search": true,
  "action_type": "search_website",
  "target": "youtube",
  "query": "aula de python",
  "entities": {{}},
  "answer_hint": "Pesquisar aula de python no YouTube"
}}

Usuário: qual curso eu quero fazer?
JSON:
{{
  "intent": "ask_memory",
  "domain": "academic",
  "confidence": 0.9,
  "should_execute": false,
  "should_search": false,
  "action_type": "",
  "target": "",
  "query": "",
  "entities": {{"memory_key": "target_course"}},
  "answer_hint": "Responder curso alvo salvo"
}}

Usuário: o que eu preciso estudar para melhorar minhas notas?
JSON:
{{
  "intent": "study_strategy",
  "domain": "academic",
  "confidence": 0.9,
  "should_execute": false,
  "should_search": false,
  "action_type": "",
  "target": "",
  "query": "",
  "entities": {{}},
  "answer_hint": "Gerar estratégia usando notas salvas"
}}

Nome salvo do usuário: {memory_name or "desconhecido"}
Mensagem normalizada: {normalized_input}

Mensagem do usuário:
{user_input}
""".strip()

    def _extract_json(self, text: str) -> dict | None:
        if not text:
            return None

        try:
            return json.loads(text.strip())
        except Exception:
            pass

        match = re.search(r"\{.*\}", text, re.DOTALL)
        if not match:
            return None

        try:
            return json.loads(match.group(0))
        except Exception:
            return None

    def _safe_default(self, user_input: str) -> dict:
        return {
            "intent": "clarify",
            "domain": "general",
            "confidence": 0.0,
            "should_execute": False,
            "should_search": False,
            "action_type": "",
            "target": "",
            "query": "",
            "entities": {},
            "answer_hint": "Não entendi com segurança.",
        }

    def _normalize_intent(self, data: dict) -> dict:
        intent = str(data.get("intent") or "clarify").strip()
        domain = str(data.get("domain") or "general").strip()
        action_type = str(data.get("action_type") or "").strip()

        if intent not in ALLOWED_INTENTS:
            intent = "clarify"

        if domain not in ALLOWED_DOMAINS:
            domain = "general"

        if action_type and action_type not in ALLOWED_ACTION_TYPES:
            action_type = ""

        try:
            confidence = float(data.get("confidence", 0.0))
        except (TypeError, ValueError):
            confidence = 0.0

        confidence = max(0.0, min(confidence, 1.0))
        should_execute = bool(data.get("should_execute", False))
        should_search = bool(data.get("should_search", False))

        if intent not in {"execute_action", "search_web"}:
            should_execute = False
            should_search = False
            action_type = ""

        if intent == "execute_action":
            should_search = False

        if intent == "search_web":
            should_execute = bool(should_execute and should_search)
            action_type = "search_website" if should_search else ""

        if not should_execute:
            action_type = ""

        if not should_search and intent != "execute_action":
            should_search = False

        entities = data.get("entities")
        if not isinstance(entities, dict):
            entities = {}

        return {
            "intent": intent,
            "domain": domain,
            "confidence": confidence,
            "should_execute": should_execute,
            "should_search": should_search,
            "action_type": action_type,
            "target": str(data.get("target") or "").strip(),
            "query": str(data.get("query") or "").strip(),
            "entities": entities,
            "answer_hint": str(data.get("answer_hint") or "").strip(),
        }
