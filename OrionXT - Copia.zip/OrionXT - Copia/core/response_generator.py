import json
import re

from core.labels import display_target


ACTION_TYPES = {
    "open_app",
    "close_app",
    "open_website",
    "search_website",
    "open_folder",
    "multi_action",
}

MAX_RESPONSE_CHARS = 280
MAX_CONTEXT_TEXT_CHARS = 180

ACTION_SUCCESS_CLAIMS = (
    "abri",
    "abrindo",
    "fechei",
    "fechando",
    "pesquisei",
    "pesquisando",
    "executei",
    "pronto",
    "concluido",
    "concluído",
)

ACTION_FAILURE_CLAIMS = (
    "não vou",
    "nao vou",
    "não consegui",
    "nao consegui",
    "não executei",
    "nao executei",
)


class ResponseGenerator:
    """Transforma resultados técnicos em fala natural.

    Esta camada não recebe Router, Validator ou actions. Ela só narra o que já
    foi decidido e executado por outras partes do OrionXT.
    """

    def __init__(self, client=None):
        self.client = client

    def generate(
        self,
        user_input: str,
        interpretation: dict | None = None,
        decision: dict | None = None,
        observation=None,
        context: dict | None = None,
        success: bool | None = None,
        response_type: str = "action_result",
        fallback: str = "",
        error: str = "",
    ) -> str:
        observation_data = self._observation_dict(observation)
        observation_text = self._observation_text(observation_data)
        effective_success = self._effective_success(success, observation_data)
        fallback_response = self._fallback_response(
            decision=decision,
            observation_text=observation_text,
            success=effective_success,
            response_type=response_type,
            fallback=fallback,
            error=error,
        )

        if self.client is None:
            return fallback_response

        prompt = self._build_prompt(
            user_input=user_input,
            interpretation=interpretation,
            decision=decision,
            observation_data=observation_data,
            context=context,
            success=effective_success,
            response_type=response_type,
            fallback=fallback_response,
            error=error,
        )

        try:
            generated = str(self.client.generate(prompt) or "").strip()
        except Exception as exc:
            print("Erro no ResponseGenerator:", repr(exc))
            return fallback_response

        generated = self._clean_generated(generated)

        if not self._is_safe_generated_response(
            generated,
            decision=decision,
            success=effective_success,
            response_type=response_type,
        ):
            return fallback_response

        return generated

    def _build_prompt(
        self,
        user_input: str,
        interpretation: dict | None,
        decision: dict | None,
        observation_data: dict,
        context: dict | None,
        success: bool | None,
        response_type: str,
        fallback: str,
        error: str,
    ) -> str:
        payload = {
            "mensagem_usuario": user_input,
            "tipo_resposta": response_type,
            "intencao": interpretation or {},
            "decisao_validada": decision or {},
            "observacao": observation_data,
            "sucesso": success,
            "erro_validacao": error,
            "contexto_recente": self._compact_context(context),
            "fallback_seguro": fallback,
        }

        return f"""
Você é a voz final do OrionXT.

Sua tarefa é transformar o resultado técnico abaixo em UMA resposta curta,
natural e contextual em português do Brasil.

Regras obrigatórias:
- Não decida intenção.
- Não execute ações.
- Não mude target, query ou tipo de ação.
- Não invente sucesso.
- Se sucesso=false, não diga que abriu, fechou, pesquisou ou executou.
- Se for bloqueio de segurança, seja firme e claro.
- Se for ambiguidade, peça reformulação de forma natural.
- Se o fallback seguro já estiver bom, você pode reaproveitar a ideia.
- Responda apenas com a fala final, sem JSON.

Dados:
{json.dumps(payload, ensure_ascii=False)}
""".strip()

    def _fallback_response(
        self,
        decision: dict | None,
        observation_text: str,
        success: bool | None,
        response_type: str,
        fallback: str,
        error: str,
    ) -> str:
        if fallback:
            return fallback

        if response_type == "blocked":
            return "Entendido. Não vou executar essa ação."

        if response_type in {"clarify", "validation_error"}:
            return "Não entendi com segurança. Pode reformular?"

        if response_type == "chat":
            return "Entendi."

        if success is False:
            if observation_text:
                return f"Não consegui concluir isso: {observation_text}"

            if error:
                return f"Não consegui fazer isso com segurança: {error}"

            return "Não consegui executar essa ação com segurança."

        action_type = (decision or {}).get("type", "")

        if action_type in ACTION_TYPES:
            return self._fallback_action_success(decision or {}, observation_text)

        return observation_text or "Entendido."

    def _fallback_action_success(self, decision: dict, observation_text: str = "") -> str:
        action_type = decision.get("type", "")
        target = decision.get("target", "")
        query = decision.get("query", "")
        label = display_target(target)

        if action_type == "open_website":
            return f"Claro, abrindo o {label}."

        if action_type == "open_app":
            return f"Fechado, abrindo o {label}."

        if action_type == "close_app":
            return f"Fechado, fechando o {label}."

        if action_type == "open_folder":
            return f"Claro, abrindo {label}."

        if action_type == "search_website":
            if query:
                return f"Certo, vou pesquisar {query} no {label}."
            return f"Certo, vou pesquisar no {label}."

        if action_type == "multi_action":
            return "Certo, executei as ações em sequência."

        return observation_text or "Pronto."

    def _observation_dict(self, observation) -> dict:
        if observation is None:
            return {}

        if hasattr(observation, "to_dict"):
            return observation.to_dict()

        if isinstance(observation, dict):
            return observation

        return {
            "success": getattr(observation, "success", None),
            "result": getattr(observation, "result", ""),
        }

    def _observation_text(self, observation_data: dict) -> str:
        return str(observation_data.get("result") or "").strip()

    def _effective_success(self, success: bool | None, observation_data: dict) -> bool | None:
        if success is not None:
            return success

        observed_success = observation_data.get("success")

        if isinstance(observed_success, bool):
            return observed_success

        return None

    def _compact_context(self, context: dict | None) -> dict:
        if not isinstance(context, dict):
            return {}

        compact = {}

        if "memory_context" in context:
            compact["memory_context"] = context.get("memory_context") or {}

        history = context.get("recent_history")
        if isinstance(history, list):
            compact["recent_history"] = [
                self._compact_history_item(item)
                for item in history[-3:]
                if isinstance(item, dict)
            ]

        return compact

    def _compact_history_item(self, item: dict) -> dict:
        return {
            "user": self._truncate_text(item.get("user", "")),
            "assistant": self._truncate_text(item.get("assistant", "")),
        }

    def _truncate_text(self, value) -> str:
        text = str(value or "")

        if len(text) <= MAX_CONTEXT_TEXT_CHARS:
            return text

        return text[: MAX_CONTEXT_TEXT_CHARS - 3].rstrip() + "..."

    def _clean_generated(self, text: str) -> str:
        text = re.sub(r"\s+", " ", text).strip()
        text = text.strip("\"'` ")

        if len(text) > MAX_RESPONSE_CHARS:
            text = text[: MAX_RESPONSE_CHARS - 3].rstrip() + "..."

        return text

    def _is_safe_generated_response(
        self,
        text: str,
        decision: dict | None,
        success: bool | None,
        response_type: str,
    ) -> bool:
        if not text:
            return False

        lowered = text.lower()

        if lowered.startswith("erro ao falar com o ollama"):
            return False

        if "sem executar nenhuma ação" in lowered or "sem executar nenhuma acao" in lowered:
            return False

        if response_type == "blocked":
            return "não" in lowered or "nao" in lowered

        if success is False:
            return not any(claim in lowered for claim in ACTION_SUCCESS_CLAIMS)

        action_type = (decision or {}).get("type", "")

        if success is True and action_type in ACTION_TYPES:
            return not any(claim in lowered for claim in ACTION_FAILURE_CLAIMS)

        return True
