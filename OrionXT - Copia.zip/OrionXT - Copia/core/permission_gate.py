import re
from copy import deepcopy

from core.patterns import (
    action_mentioned_as_topic,
    explicit_search_requested,
    forbids_action,
    forbids_search,
)
from core.utils import normalize_text
from registry.apps import APPS
from registry.folders import FOLDERS
from registry.resolver import resolve_app, resolve_folder, resolve_website
from registry.websites import WEBSITES


ACTION_TYPES = {
    "open_app",
    "close_app",
    "open_website",
    "search_website",
    "open_folder",
    "multi_action",
}

OPEN_ACTIONS = {"open_app", "open_website", "open_folder"}
CRITICAL_CLOSE_TARGETS = {"explorador"}
VAGUE_REFERENCES = {
    "isso",
    "isto",
    "aquilo",
    "esse",
    "essa",
    "aquele",
    "aquela",
    "ele",
    "ela",
    "eles",
    "elas",
    "ai",
    "ali",
    "la",
    "coisa",
    "negocio",
    "nada",
}
ACTION_WORDS = (
    "abrir",
    "abre",
    "abra",
    "fechar",
    "fecha",
    "pesquisar",
    "pesquisa",
    "procura",
    "buscar",
    "busca",
    "executar",
)


class PermissionGate:
    """Politica deterministica para permitir ou bloquear execucao.

    O gate nao interpreta intencao, nao chama LLM e nao executa acoes. Ele apenas
    confere se uma decisao ja validada pode chegar ao Router.
    """

    def check(
        self,
        user_input: str,
        decision: dict,
        interpretation: dict | None = None,
        context: dict | None = None,
        validation_result: tuple[bool, str] | None = None,
    ) -> dict:
        if validation_result is not None:
            valid, error = validation_result
            if not valid:
                return self._deny(
                    f"Validação falhou antes da execução: {error}",
                    safe_decision=decision,
                )

        if not isinstance(decision, dict):
            return self._deny("A decisão técnica não está em um formato seguro.")

        action_type = str(decision.get("type") or "").strip()

        if action_type == "chat":
            return self._allow(decision)

        if action_type not in ACTION_TYPES:
            return self._deny(f"Tipo de ação não permitido: {action_type}", safe_decision=decision)

        text = normalize_text(user_input)
        global_block = self._global_block_reason(text, action_type)
        if global_block:
            return self._deny(global_block, safe_decision=decision)

        if action_type == "multi_action":
            return self._check_multi_action(user_input, decision, interpretation, context)

        return self._check_single_action(user_input, decision, interpretation, context)

    def _check_multi_action(
        self,
        user_input: str,
        decision: dict,
        interpretation: dict | None,
        context: dict | None,
    ) -> dict:
        items = decision.get("items")

        if not isinstance(items, list) or not items:
            return self._deny("Não executei a sequência porque ela não tem ações claras.", safe_decision=decision)

        safe_items = []

        for item in items:
            result = self._check_single_action(user_input, item, interpretation, context)

            if not result.get("allowed"):
                reason = result.get("reason") or "um item da sequência não ficou seguro."
                return self._deny(
                    f"Não executei a sequência porque {self._sequence_reason(reason)}",
                    requires_confirmation=bool(result.get("requires_confirmation")),
                    safe_decision=decision,
                )

            if result.get("requires_confirmation"):
                return self._deny(
                    "Não executei a sequência porque uma das ações precisa de confirmação.",
                    requires_confirmation=True,
                    safe_decision=decision,
                )

            safe_items.append(result.get("safe_decision") or item)

        safe_decision = deepcopy(decision)
        safe_decision["items"] = safe_items
        return self._allow(safe_decision)

    def _check_single_action(
        self,
        user_input: str,
        decision: dict,
        interpretation: dict | None,
        context: dict | None,
    ) -> dict:
        action_type = str(decision.get("type") or "").strip()

        if action_type == "open_website":
            return self._check_open_target(user_input, decision, resolve_website, WEBSITES, "site")

        if action_type == "open_app":
            return self._check_open_target(user_input, decision, resolve_app, APPS, "aplicativo")

        if action_type == "open_folder":
            return self._check_open_target(user_input, decision, resolve_folder, FOLDERS, "pasta")

        if action_type == "close_app":
            return self._check_close_app(user_input, decision)

        if action_type == "search_website":
            return self._check_search(user_input, decision)

        return self._deny(f"Tipo de ação não permitido: {action_type}", safe_decision=decision)

    def _check_open_target(self, user_input: str, decision: dict, resolver, registry: dict, label: str) -> dict:
        target = str(decision.get("target") or "").strip()
        target_key, target_data = resolver(target)

        if not target_data:
            return self._deny(f"Não executei porque o {label} não está no registry.", safe_decision=decision)

        if not self._target_clearly_mentioned(user_input, target_key, target_data):
            if self._has_vague_reference(user_input):
                return self._deny(f"Não executei porque não ficou claro qual {label} você quer abrir.", safe_decision=decision)

            return self._deny(f"Não executei porque você não citou claramente qual {label} quer abrir.", safe_decision=decision)

        return self._allow(self._with_target(decision, target_key))

    def _check_close_app(self, user_input: str, decision: dict) -> dict:
        target = str(decision.get("target") or "").strip()
        app_key, app_data = resolve_app(target)

        if not app_data:
            return self._deny("Não fechei porque o aplicativo está fora do registry.", safe_decision=decision)

        if app_key in CRITICAL_CLOSE_TARGETS:
            return self._deny(f"Não vou fechar {app_key}, porque é um processo sensível do Windows.", safe_decision=decision)

        if not self._target_clearly_mentioned(user_input, app_key, app_data):
            return self._deny(
                "Preciso que você diga claramente qual aplicativo quer fechar.",
                requires_confirmation=True,
                safe_decision=decision,
            )

        return self._allow(self._with_target(decision, app_key))

    def _check_search(self, user_input: str, decision: dict) -> dict:
        target = str(decision.get("target") or "").strip()
        query = str(decision.get("query") or "").strip()
        site_key, site_data = resolve_website(target)

        if not site_data:
            return self._deny("Não pesquisei porque o site está fora do registry.", safe_decision=decision)

        if not explicit_search_requested(user_input):
            return self._deny("Não pesquisei porque a mensagem não foi um pedido claro de pesquisa.", safe_decision=decision)

        if not query or self._is_vague_text(query):
            return self._deny("Não pesquisei porque não ficou claro o que você quer pesquisar.", safe_decision=decision)

        safe_decision = self._with_target(decision, site_key)
        safe_decision["query"] = query
        return self._allow(safe_decision)

    def _global_block_reason(self, text: str, action_type: str) -> str:
        if self._contains_search(action_type) and forbids_search(text, include_soft=True):
            return "Não vou pesquisar porque você pediu para não pesquisar."

        if forbids_action(text):
            return "Não executei porque você pediu para não executar ações."

        if action_mentioned_as_topic(text) or self._looks_like_action_question(text):
            return "Não executei porque a ação apareceu como assunto, não como comando."

        return ""

    def _contains_search(self, action_type: str) -> bool:
        return action_type == "search_website"

    def _looks_like_action_question(self, text: str) -> bool:
        if not any(word in text for word in ACTION_WORDS):
            return False

        return text.startswith(("como ", "o que ", "o que significa ", "como funciona "))

    def _target_clearly_mentioned(self, user_input: str, target_key: str, target_data: dict) -> bool:
        text = normalize_text(user_input)
        names = [target_key, *target_data.get("aliases", [])]

        for name in names:
            normalized_name = normalize_text(name)

            if normalized_name and self._contains_phrase(text, normalized_name):
                return True

        return False

    def _contains_phrase(self, text: str, phrase: str) -> bool:
        return bool(re.search(rf"(?<!\w){re.escape(phrase)}(?!\w)", text))

    def _has_vague_reference(self, text: str) -> bool:
        normalized = normalize_text(text)
        return any(self._contains_phrase(normalized, word) for word in VAGUE_REFERENCES)

    def _is_vague_text(self, text: str) -> bool:
        normalized = normalize_text(text).strip(" .?!,;:-")
        return normalized in VAGUE_REFERENCES

    def _with_target(self, decision: dict, target: str) -> dict:
        safe_decision = deepcopy(decision)
        safe_decision["target"] = target
        return safe_decision

    def _allow(self, safe_decision: dict) -> dict:
        return {
            "allowed": True,
            "requires_confirmation": False,
            "reason": "",
            "safe_decision": deepcopy(safe_decision),
        }

    def _deny(self, reason: str, requires_confirmation: bool = False, safe_decision: dict | None = None) -> dict:
        return {
            "allowed": False,
            "requires_confirmation": requires_confirmation,
            "reason": reason,
            "safe_decision": deepcopy(safe_decision) if isinstance(safe_decision, dict) else {},
        }

    def _lower_first(self, text: str) -> str:
        text = str(text or "").strip()

        if not text:
            return "um item da sequência não ficou seguro."

        return text[:1].lower() + text[1:]

    def _sequence_reason(self, reason: str) -> str:
        reason = str(reason or "").strip()

        for prefix in ("Não executei porque ", "Não pesquisei porque "):
            if reason.startswith(prefix):
                return self._lower_first(reason[len(prefix):])

        return self._lower_first(reason)
