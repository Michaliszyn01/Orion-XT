from core.handlers.academic_memory import (
    clean_course,
    format_area_name,
    format_enem_scores_response,
    format_university_list,
    join_list,
    looks_like_question,
    normalize_university_list,
)
from core.handlers.memory_repository import MemoryRepository
from core.utils import normalize_text


class MemoryHandler:
    def __init__(self, memory, memory_store=None, repository: MemoryRepository | None = None):
        self.memory = memory
        self.memory_store = memory_store
        self.repository = repository or MemoryRepository(memory_store)

    def handle_ask_memory(self, interpretation: dict) -> str:
        memory_key = interpretation.get("entities", {}).get("memory_key", "")

        if memory_key == "target_course":
            course = self.get_memory_value("academic_goal", "target_course")
            universities = self.get_universities_value()
            parts = []

            if course:
                parts.append(f"Seu curso alvo é {course}.")

            if universities:
                parts.append(f"Suas universidades alvo são {format_university_list(universities)}.")

            if parts:
                return " ".join(parts)

            return "Ainda não tenho seu curso alvo registrado."

        if memory_key in {"target_university", "target_universities"}:
            universities = self.get_universities_value()

            if universities:
                return f"Suas universidades alvo são {format_university_list(universities)}."

            return "Ainda não tenho universidades alvo registradas."

        if memory_key == "enem_scores":
            return self.format_enem_scores_response()

        if memory_key == "enem_target":
            target = self.get_memory_value("enem", "target_score")

            if target:
                return f"Sua meta registrada para o ENEM é {target}."

            return "Ainda não tenho uma meta do ENEM registrada."

        if memory_key == "user_name":
            name = self.memory.get_name()

            if name:
                return f"Seu nome é {name}."

            return 'Ainda não sei seu nome. Você pode dizer: "meu nome é Marcos".'

        return "Ainda não tenho essa informação registrada na memória."

    def handle_save_memory(self, interpretation: dict, user_input: str = "") -> str:
        if user_input and looks_like_question(user_input):
            return "Não vou salvar uma pergunta como memória. Posso consultar o que já está salvo para te responder."

        entities = interpretation.get("entities", {})
        saved = []
        course = clean_course(entities.get("target_course", ""))
        universities = normalize_university_list(
            entities.get("target_universities") or entities.get("target_university") or []
        )

        if course:
            self.save_long_memory("academic_goal", "target_course", course, importance=4)
            saved.append("curso")

        if universities:
            self.save_long_memory("academic_goal", "target_universities", ", ".join(universities), importance=4)
            saved.append("universidades")

        enem_score = entities.get("enem_score")
        if enem_score:
            self.save_long_memory("enem", "last_score", str(enem_score), importance=4)
            saved.append("nota geral do ENEM")

        area_scores = entities.get("enem_area_scores")
        if isinstance(area_scores, dict):
            for area, score in area_scores.items():
                self.save_long_memory("enem_area_scores", normalize_text(area), str(score), importance=4)
            saved.append("notas por área")

        study_goal = entities.get("study_goal")
        if study_goal:
            self.save_long_memory("study", "study_goal", str(study_goal), importance=3)
            saved.append("objetivo de estudo")

        if course and universities:
            return (
                f"Entendido. Registrei {course} como curso alvo e "
                f"{join_list(universities)} como universidades alvo."
            )

        if course:
            return f"Entendido. Registrei {course} como curso alvo."

        if universities:
            return f"Entendido. Registrei {join_list(universities)} como universidades alvo."

        if saved:
            return "Entendido. Registrei essa informação na memória."

        return "Não encontrei uma informação clara para salvar. Pode me dizer de forma mais direta?"

    def handle_update_preference(self, interpretation: dict) -> str:
        entities = interpretation.get("entities", {})

        if "allow_auto_search" in entities:
            value = "true" if bool(entities.get("allow_auto_search")) else "false"

            self.repository.set_preference("allow_auto_search", value)
            self.memory.data.setdefault("preferences", {})["allow_auto_search"] = value
            self.memory.save()

            return (
                "Entendido. Registrei essa preferência. Mesmo assim, vou priorizar memória "
                "e conhecimento local antes de pesquisar."
            )

        return "Entendido. Vou guardar essa preferência quando ela estiver mais clara."

    def get_memory_value(self, category: str, key: str) -> str:
        return self.repository.get_memory_value(category, key)

    def get_universities_value(self) -> str:
        return self.repository.get_universities_value()

    def get_area_scores(self) -> dict:
        return self.repository.get_area_scores()

    def format_enem_scores_response(self) -> str:
        score = self.get_memory_value("enem", "last_score")
        return format_enem_scores_response(score, self.get_area_scores())

    def save_long_memory(self, category: str, key: str, value: str, importance: int = 1):
        self.repository.save_long_memory(category, key, value, importance=importance)

    def format_area_name(self, area: str) -> str:
        return format_area_name(area)

    def format_university_list(self, value: str) -> str:
        return format_university_list(value)

    def normalize_university_list(self, value) -> list[str]:
        return normalize_university_list(value)

    def clean_course(self, value: str) -> str:
        return clean_course(value)

    def looks_like_question(self, user_input: str) -> bool:
        return looks_like_question(user_input)

    def join_list(self, items: list[str]) -> str:
        return join_list(items)
