"""Handlers pequenos usados pelo Assistant."""
