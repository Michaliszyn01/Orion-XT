from core.handlers.academic_memory import join_list


class StudyHandler:
    def __init__(self, memory_handler):
        self.memory_handler = memory_handler

    def handle_study_strategy(self, interpretation: dict) -> str:
        area_scores = self.memory_handler.get_area_scores()

        if not area_scores:
            return (
                "Para montar uma estratégia precisa, preciso que você me informe sua nota geral "
                "e, se possível, suas notas por área."
            )

        priorities = []

        redacao = self._to_int(area_scores.get("redacao"))
        matematica = self._to_int(area_scores.get("matematica"))
        natureza = self._to_int(area_scores.get("natureza"))
        linguagens = self._to_int(area_scores.get("linguagens"))
        humanas = self._to_int(area_scores.get("humanas"))

        if matematica is not None and matematica < 700:
            priorities.append("Matemática")

        if redacao is not None and redacao < 900:
            priorities.append("Redação")

        if natureza is not None and natureza < 650:
            priorities.append("Natureza")

        if linguagens is not None and linguagens < 650:
            priorities.append("Linguagens")

        if humanas is not None and humanas < 650:
            priorities.append("Humanas")

        if not priorities:
            return (
                "Suas notas não mostram uma área crítica óbvia. Eu manteria revisão leve, "
                "questões semanais e foco em redação para consolidar pontos."
            )

        return (
            f"Com suas notas atuais, eu priorizaria {join_list(priorities[:3])}. "
            "Matemática costuma dar bom retorno, redação pode subir com treino estruturado, "
            "e as áreas abaixo de 650 pedem revisão de base com questões. Um bom próximo passo "
            "é fazer 1 bloco de Matemática, 1 redação e 1 lista da área mais fraca nesta semana."
        )

    def _to_int(self, value) -> int | None:
        try:
            return int(value)
        except (TypeError, ValueError):
            return None
