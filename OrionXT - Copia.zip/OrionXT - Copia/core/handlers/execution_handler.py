class ExecutionHandler:
    def __init__(
        self,
        router,
        validator,
        permission_gate,
        response_generator,
        response_context_provider,
    ):
        self.router = router
        self.validator = validator
        self.permission_gate = permission_gate
        self.response_generator = response_generator
        self.response_context_provider = response_context_provider

    def generate_final_response(
        self,
        user_input: str,
        interpretation: dict | None = None,
        decision: dict | None = None,
        observation=None,
        success: bool | None = None,
        response_type: str = "action_result",
        fallback: str = "",
        error: str = "",
    ) -> str:
        return self.response_generator.generate(
            user_input=user_input,
            interpretation=interpretation,
            decision=decision,
            observation=observation,
            context=self.response_context_provider(),
            success=success,
            response_type=response_type,
            fallback=fallback,
            error=error,
        )

    def execute_decision(self, user_input: str, decision: dict, interpretation: dict | None = None) -> str:
        valid, error = self.validator.validate(decision)

        if not valid:
            return self.generate_final_response(
                user_input=user_input,
                interpretation=interpretation,
                decision=decision,
                response_type="validation_error",
                success=False,
                fallback="Não consegui entender com segurança. Pode reformular?",
                error=error,
            )

        if decision.get("type") == "chat":
            return decision.get("answer", "Entendi.")

        permission = self.permission_gate.check(
            user_input=user_input,
            decision=decision,
            interpretation=interpretation,
            context=self.response_context_provider(),
            validation_result=(valid, error),
        )

        if not permission.get("allowed"):
            return self.generate_final_response(
                user_input=user_input,
                interpretation=interpretation,
                decision=decision,
                response_type="blocked" if not permission.get("requires_confirmation") else "clarify",
                success=False,
                fallback=permission.get("reason") or "Não executei porque essa ação não ficou segura.",
            )

        safe_decision = permission.get("safe_decision") or decision
        observation = self.router.execute(safe_decision)

        return self.generate_final_response(
            user_input=user_input,
            interpretation=interpretation,
            decision=safe_decision,
            observation=observation,
            response_type="action_result",
            success=observation.success,
        )

    def build_decision_from_interpretation(self, interpretation: dict) -> dict | None:
        intent = interpretation.get("intent")
        should_execute = bool(interpretation.get("should_execute"))
        should_search = bool(interpretation.get("should_search"))
        action_type = interpretation.get("action_type", "")
        target = interpretation.get("target", "")
        query = interpretation.get("query", "")

        if intent == "search_web" and not should_search:
            return None

        if intent == "execute_action" and not should_execute:
            return None

        if action_type == "search_website" and not should_search:
            return None

        if not should_execute or not action_type:
            return None

        if action_type == "multi_action":
            items = interpretation.get("entities", {}).get("items")
            if not isinstance(items, list) or not items:
                return None

            return {
                "type": "multi_action",
                "items": items,
            }

        decision = {"type": action_type}

        if target:
            decision["target"] = target

        if action_type == "search_website":
            decision["target"] = target or "google"
            decision["query"] = query

        return decision
