import webbrowser

from core.modes import ORION_SPOTIFY_URL
from core.utils import normalize_text


def is_orion_mode_command(text: str) -> bool:
    text = normalize_text(text)

    aliases = [
        "modo orion",
        "mado orion",
        "moto orion",
        "modo audio",
        "modo oreo",
        "moutro oreo",
        "outro oreo",
        "orion",
    ]

    return any(alias in text for alias in aliases)


def is_activate_orion_command(text: str) -> bool:
    text = normalize_text(text)

    activation_words = [
        "ativa",
        "ativar",
        "inicia",
        "iniciar",
        "liga",
        "ligar",
    ]

    standalone_commands = [
        "modo orion",
        "mado orion",
        "moto orion",
        "modo audio",
        "modo oreo",
        "moutro oreo",
        "outro oreo",
    ]

    words = set(text.split())

    return is_orion_mode_command(text) and (
        any(word in words for word in activation_words)
        or text in standalone_commands
    )


def is_deactivate_orion_command(text: str) -> bool:
    text = normalize_text(text)

    return (
        "modo normal" in text
        or "sair do modo orion" in text
        or "desativar modo orion" in text
        or "desativa modo orion" in text
    )


class ModeHandler:
    def __init__(self, mode_manager, theme_url: str = ORION_SPOTIFY_URL, opener=None):
        self.mode_manager = mode_manager
        self.theme_url = theme_url
        self.opener = opener or webbrowser.open

    def handle(self, user_input: str) -> str | None:
        if is_activate_orion_command(user_input):
            self.mode_manager.activate_orion_mode()
            self._open_orion_theme()
            return "Modo Orion ativado. Estou online e pronto para operar."

        if is_deactivate_orion_command(user_input):
            self.mode_manager.deactivate_orion_mode()
            return "Modo Orion desativado. Voltando ao modo normal."

        return None

    def _open_orion_theme(self):
        try:
            self.opener(self.theme_url)
        except Exception as exc:
            print("Erro ao abrir musica do Modo Orion:", repr(exc))
