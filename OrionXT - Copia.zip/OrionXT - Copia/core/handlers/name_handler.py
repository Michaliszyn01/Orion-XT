import re

from core.utils import normalize_text


class NameHandler:
    def __init__(self, memory):
        self.memory = memory

    def handle(self, user_input: str) -> str | None:
        name_answer = self.handle_name_command(user_input)
        if name_answer is not None:
            return name_answer

        return self.handle_name_question(user_input)

    def handle_name_command(self, user_input: str) -> str | None:
        match = re.match(r"\s*meu\s+nome\s+(?:e|é|eh)\s+(.+?)\s*$", user_input, re.IGNORECASE)

        if not match:
            return None

        name = match.group(1).strip(" .?!,;:-")

        if not name:
            return None

        self.memory.set_name(name)
        return f"Entendido. Vou te chamar de {name}."

    def handle_name_question(self, user_input: str) -> str | None:
        text = normalize_text(user_input)
        asks_user_name = any(phrase in text for phrase in [
            "qual e meu nome",
            "qual e o meu nome",
            "qual o meu nome",
            "como eu me chamo",
        ])
        asks_assistant_name = any(phrase in text for phrase in [
            "qual e seu nome",
            "qual e o seu nome",
            "qual o seu nome",
            "e o seu nome",
            "quem e voce",
        ])

        if not asks_user_name and not asks_assistant_name:
            return None

        user_name = self.memory.get_name()

        if asks_user_name and asks_assistant_name:
            if user_name:
                return f"Seu nome é {user_name}. Meu nome é OrionXT."

            return "Ainda não sei seu nome. Meu nome é OrionXT."

        if asks_user_name:
            if user_name:
                return f"Seu nome é {user_name}."

            return 'Ainda não sei seu nome. Você pode dizer: "meu nome é Marcos".'

        return "Meu nome é OrionXT. Sou seu assistente pessoal."
