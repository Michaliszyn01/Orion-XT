from core.handlers.academic_memory import VALID_ENEM_AREAS


class MemoryRepository:
    def __init__(self, memory_store=None):
        self.memory_store = memory_store

    def get_memory_value(self, category: str, key: str) -> str:
        if self.memory_store is None:
            return ""

        try:
            memories = self.memory_store.get_relevant_memories(category=category, limit=30)
        except Exception as exc:
            print("Erro ao buscar memória:", repr(exc))
            return ""

        for memory in memories:
            memory_key = memory.get("key") or memory.get("memory_key") or memory.get("name")
            value = memory.get("value") or memory.get("content") or ""

            if memory_key == key and value:
                return str(value)

        return ""

    def get_universities_value(self) -> str:
        return (
            self.get_memory_value("academic_goal", "target_universities")
            or self.get_memory_value("academic_goal", "target_university")
        )

    def get_area_scores(self) -> dict:
        if self.memory_store is None:
            return {}

        try:
            memories = self.memory_store.get_relevant_memories(category="enem_area_scores", limit=30)
        except Exception as exc:
            print("Erro ao buscar notas:", repr(exc))
            return {}

        scores = {}

        for memory in memories:
            area = memory.get("key") or memory.get("memory_key") or memory.get("name")
            value = memory.get("value") or memory.get("content") or ""

            if area in VALID_ENEM_AREAS and value:
                scores[area] = str(value)

        return scores

    def save_long_memory(self, category: str, key: str, value: str, importance: int = 1):
        if self.memory_store is None:
            return

        try:
            self.memory_store.save_long_memory(
                category=category,
                key=key,
                value=value,
                importance=importance,
                metadata={"source": "intent_interpreter"},
            )
        except Exception as exc:
            print("Erro ao salvar memória:", repr(exc))

    def set_preference(self, key: str, value: str):
        if self.memory_store is None:
            return

        try:
            self.memory_store.set_preference(key, value)
        except Exception as exc:
            print("Erro ao salvar preferencia:", repr(exc))
