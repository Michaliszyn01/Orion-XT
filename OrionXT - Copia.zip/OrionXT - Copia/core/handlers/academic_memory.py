import re

from core.utils import normalize_text


VALID_ENEM_AREAS = {"matematica", "linguagens", "humanas", "natureza", "redacao"}

ENEM_AREA_NAMES = {
    "matematica": "Matemática e suas Tecnologias",
    "linguagens": "Linguagens, Códigos e suas Tecnologias",
    "humanas": "Ciências Humanas e suas Tecnologias",
    "natureza": "Ciências da Natureza e suas Tecnologias",
    "redacao": "Redação",
}

QUESTION_STARTS = (
    "qual ",
    "quais ",
    "o que ",
    "que ",
    "como ",
    "quando ",
    "onde ",
    "por que ",
    "porque ",
    "cade ",
)


def format_enem_scores_response(score: str, area_scores: dict) -> str:
    ordered_areas = ["matematica", "linguagens", "humanas", "natureza", "redacao"]
    lines = []

    for area in ordered_areas:
        value = area_scores.get(area)

        if value:
            lines.append(f"- {format_area_name(area)}: {value}")

    if not score and not lines:
        return (
            "Eu não consigo acessar o sistema oficial do ENEM. Mas posso te mostrar as notas "
            "que você me informou. Ainda não encontrei notas registradas."
        )

    response_parts = []

    if lines:
        response_parts.append("Suas notas registradas do ENEM são:\n" + "\n".join(lines))

    if score:
        response_parts.append(f"Nota geral registrada: {score}.")

    return "\n".join(response_parts)


def format_area_name(area: str) -> str:
    return ENEM_AREA_NAMES.get(area, area)


def format_university_list(value: str) -> str:
    universities = [
        item.strip().upper()
        for item in re.split(r"[,;]", value)
        if item.strip()
    ]
    return join_list(universities) if universities else value


def normalize_university_list(value) -> list[str]:
    if isinstance(value, str):
        items = re.split(r"[,;/]|\sou\s", value)
    elif isinstance(value, list):
        items = value
    else:
        items = []

    normalized = []
    for item in items:
        text = normalize_text(str(item))
        if not text:
            continue

        if text in {"ufpr", "universidade federal do parana", "federal do parana"}:
            university = "UFPR"
        elif text in {"utfpr", "uftpr", "universidade tecnologica federal do parana", "tecnologica federal do parana"}:
            university = "UTFPR"
        elif text in {"pucpr", "puc pr", "puc-pr", "puc parana", "puc do parana", "puccpr"}:
            university = "PUCPR"
        else:
            university = str(item).strip().upper()

        if university and university not in normalized:
            normalized.append(university)

    return normalized


def clean_course(value: str) -> str:
    text = normalize_text(str(value or ""))

    if text in {"engenharia de software", "engenharia software", "engenheiro de software", "software engineering"}:
        return "Engenharia de Software"

    return str(value or "").strip()


def looks_like_question(user_input: str) -> bool:
    text = normalize_text(user_input)
    return "?" in user_input or text.startswith(QUESTION_STARTS)


def join_list(items: list[str]) -> str:
    if not items:
        return ""

    if len(items) == 1:
        return items[0]

    return ", ".join(items[:-1]) + " e " + items[-1]
