import json
import re

from core.labels import display_target
from core.patterns import action_mentioned_as_topic, explicit_search_requested, forbids_action, forbids_search
from core.utils import clean_search_query, normalize_target, normalize_text
from registry.resolver import resolve_app, resolve_folder


NO_ACTION_RESPONSE = (
    "Você tem razão. Não vou executar essa ação. Vou responder usando apenas "
    "o que eu já sei e o que está salvo na memória."
)


def is_search_negation_or_complaint(text: str) -> bool:
    return forbids_search(text, include_soft=True) or forbids_action(text)


def is_action_mentioned_as_topic(text: str) -> bool:
    return action_mentioned_as_topic(text)


def action_topic_response(text: str) -> str:
    if "abrir" in text and "google" in text:
        return (
            "Eles provavelmente queriam dizer acessar o site do Google no navegador. "
            "Não vou abrir nada; estou só explicando."
        )

    if "pesquisar" in text:
        return (
            "Pesquisar é procurar informações em uma fonte, como Google, YouTube ou outro site. "
            "Não vou pesquisar agora; estou só explicando."
        )

    return "Entendi. Você mencionou uma ação como assunto, então não vou executar nada agora."


def is_explicit_search_command(text: str) -> bool:
    return explicit_search_requested(text)


def is_general_chat_question(text: str) -> bool:
    starts = (
        "qual ",
        "quais ",
        "o que ",
        "que ",
        "como ",
        "quando ",
        "onde ",
        "por que ",
        "porque ",
        "me explica",
        "me fala sobre",
        "nao entendi",
    )
    return text.startswith(starts)


def pre_classify(user_input: str):
    text = normalize_text(user_input)

    if is_search_negation_or_complaint(text):
        return {
            "type": "chat",
            "thought": "usuario negou ou reclamou de pesquisa; sem acao",
            "answer": NO_ACTION_RESPONSE,
        }

    if is_action_mentioned_as_topic(text):
        return {
            "type": "chat",
            "thought": "usuario mencionou acao como assunto; sem acao",
            "answer": action_topic_response(text),
        }

    if is_general_chat_question(text):
        return {"type": "chat"}

    return None


class Agent:
    def __init__(self, client, memory):
        self.client = client
        self.memory = memory

    def _extract_json(self, text: str):
        try:
            return json.loads(text.strip())
        except Exception:
            pass

        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(0))
            except Exception:
                return None

        return None

    def generate_chat_answer(self, user_input: str, context_hint: str = "") -> str:
        prompt = f"""
Responda em portugues do Brasil, de forma natural e objetiva.
Nao execute acoes no computador.
Se a pergunta depender de dados atuais e voce nao tiver fonte atualizada, diga isso com clareza.
Se houver contexto, use o contexto.
Evite respostas roboticas.

Contexto:
{context_hint or "nenhum"}

Mensagem do usuario:
{user_input}
""".strip()

        answer = self.client.generate(prompt).strip()
        return answer or "Entendi."

    def _generate_chat_answer(self, user_input: str) -> str:
        return self.generate_chat_answer(user_input)

    def _build_chat_decision(self, user_input: str) -> dict:
        return {
            "type": "chat",
            "thought": "pergunta explicativa; sem acao",
            "answer": self.generate_chat_answer(user_input),
        }

    def _display_target(self, target: str) -> str:
        return display_target(target)

    def _clean_candidate(self, text: str) -> str:
        text = normalize_text(text)
        text = text.split(" e ", 1)[0]
        text = re.sub(r"\b(por favor|pra mim|para mim)\b", " ", text)
        text = re.sub(r"\b(o|a|os|as|um|uma|do|da|dos|das|no|na)\b", " ", text)
        text = re.sub(r"\b(app|aplicativo|programa|site|pasta)\b", " ", text)
        text = re.sub(r"\s+", " ", text)
        return text.strip(" .?!,;:-")

    def _candidate_after_keywords(self, text: str, keywords: list[str]) -> str:
        for keyword in keywords:
            index = text.find(keyword)
            if index >= 0:
                return self._clean_candidate(text[index + len(keyword):])

        return ""

    def _open_decision(self, user_input: str) -> dict | None:
        text = normalize_text(user_input)

        if not self._is_explicit_open_request(text):
            return None

        target = normalize_target(text)
        if target:
            return {
                "type": "open_website",
                "thought": "site conhecido detectado por regra",
                "target": target,
                "answer": f"Claro, abrindo o {self._display_target(target)}.",
            }

        candidate = self._candidate_after_keywords(
            text,
            ["abre", "abra", "abrir", "entra", "entrar", "acessa", "acesse", "acessar"],
        )

        app_key, _ = resolve_app(candidate)
        if app_key:
            return {
                "type": "open_app",
                "thought": "aplicativo conhecido detectado por regra",
                "target": app_key,
                "answer": f"Fechado, abrindo o {self._display_target(app_key)}.",
            }

        folder_key, _ = resolve_folder(candidate)
        if folder_key:
            return {
                "type": "open_folder",
                "thought": "pasta conhecida detectada por regra",
                "target": folder_key,
                "answer": f"Claro, abrindo {self._display_target(folder_key)}.",
            }

        if candidate:
            return {
                "type": "open_app",
                "thought": "tentativa de abrir aplicativo nao reconhecido",
                "target": candidate,
                "answer": f"Não conheço o aplicativo {candidate}.",
            }

        return None

    def _is_explicit_open_request(self, text: str) -> bool:
        if is_search_negation_or_complaint(text) or is_action_mentioned_as_topic(text):
            return False

        if re.search(r"^(abre|abra|abrir|entra|acessa|acesse)\b", text):
            return True

        return bool(
            re.search(
                r"\b(voce pode|pode|voce consegue|consegue)\s+"
                r"(abrir|abre|entrar|entra|acessar|acessa)\b",
                text,
            )
        )

    def _close_decision(self, user_input: str) -> dict | None:
        text = normalize_text(user_input)

        if is_action_mentioned_as_topic(text):
            return None

        if not re.search(r"^(fecha|fechar|encerra|encerrar)\b|\b(pode|pode fechar|voce pode)\s+fechar\b", text):
            return None

        candidate = self._candidate_after_keywords(
            text,
            ["fechar", "fecha", "encerrar", "encerra"],
        )

        app_key, _ = resolve_app(candidate)
        target = app_key or candidate

        if not target:
            return None

        return {
            "type": "close_app",
            "thought": "fechar aplicativo detectado por regra",
            "target": target,
            "answer": f"Fechado, fechando o {self._display_target(target)}.",
        }

    def _usage_decision(self, user_input: str) -> dict | None:
        text = normalize_text(user_input)

        if not any(word in text for word in ["usar", "preciso"]):
            return None

        candidate = self._candidate_after_keywords(text, ["usar", "preciso"])
        app_key, _ = resolve_app(candidate)

        if not app_key:
            return None

        return {
            "type": "open_app",
            "thought": "intencao de usar aplicativo detectada por regra",
            "target": app_key,
            "answer": f"Fechado, abrindo o {self._display_target(app_key)}.",
        }

    def _build_search_decision(self, user_input: str) -> dict:
        text = normalize_text(user_input)
        target = normalize_target(text)
        query = clean_search_query(user_input, target)

        if not target:
            target = self.memory.get_context().get("last_website") or "google"

        if not query:
            query = text

        open_action = self._open_decision(user_input)

        if open_action and " e " in text:
            return {
                "type": "multi_action",
                "thought": "abrir e pesquisar detectado por regra",
                "items": [
                    {
                        "type": open_action["type"],
                        "target": open_action["target"],
                    },
                    {
                        "type": "search_website",
                        "target": target,
                        "query": query,
                    },
                ],
                "answer": (
                    f"Claro, abrindo o {self._display_target(open_action['target'])} "
                    f"e pesquisando {query} no {self._display_target(target)}."
                ),
            }

        return {
            "type": "search_website",
            "thought": "pesquisa detectada por regra",
            "target": target,
            "query": query,
            "answer": f"Certo, vou pesquisar {query} no {self._display_target(target)}.",
        }

    def _compact_action(self, action: dict) -> dict:
        item = {"type": action.get("type")}

        if action.get("target"):
            item["target"] = action.get("target")

        if action.get("query"):
            item["query"] = action.get("query")

        if action.get("items"):
            item["items"] = action.get("items")

        return item

    def _multi_action_decision(self, user_input: str) -> dict | None:
        text = normalize_text(user_input)

        if " e " not in text:
            return None

        has_open_request = any(word in text for word in ["abre", "abra", "abrir", "entra", "acessa"])
        has_search_request = is_explicit_search_command(text.split(" e ", 1)[-1])

        if has_open_request and has_search_request:
            return self._build_search_decision(user_input)

        parts = [part.strip() for part in text.split(" e ") if part.strip()]
        items = []

        for index, part in enumerate(parts):
            action = (
                self._close_decision(part)
                or self._open_decision(part)
                or self._usage_decision(part)
            )

            if action is None and index > 0:
                action = self._open_decision(f"abre {part}")

            if action:
                items.append(self._compact_action(action))

        if len(items) < 2:
            return None

        return {
            "type": "multi_action",
            "thought": "comando composto simples detectado por regra",
            "items": items,
            "answer": "Certo, vou executar essas ações em sequência.",
        }

    def _rule_based_decision(self, user_input: str) -> dict | None:
        multi_action = self._multi_action_decision(user_input)
        if multi_action:
            return multi_action

        return (
            self._close_decision(user_input)
            or self._open_decision(user_input)
            or self._usage_decision(user_input)
        )

    def decide(self, user_input: str, observation: dict | None = None) -> dict:
        if observation is None:
            pre = pre_classify(user_input)

            if isinstance(pre, dict) and pre.get("type") == "chat" and pre.get("answer"):
                return pre

            if pre == {"type": "chat"}:
                return self._build_chat_decision(user_input)

        name = self.memory.get_name() or "usuário"
        context = self.memory.get_context()
        history = self.memory.data.get("history", [])[-5:]

        prompt = f"""
Você é o cérebro principal do OrionXT, um assistente desktop em português do Brasil.

Você deve responder SOMENTE com JSON válido.

Tipos permitidos:
- chat
- open_app
- close_app
- open_website
- search_website
- open_folder
- multi_action

Formato chat:
{{
  "type": "chat",
  "thought": "entendi que o usuário quer apenas conversar",
  "answer": "resposta natural"
}}

Formato ação:
{{
  "type": "open_website",
  "thought": "usuário quer abrir o Google",
  "target": "google",
  "answer": "Abrindo o Google."
}}

Formato multi_action:
{{
  "type": "multi_action",
  "thought": "usuário quer abrir o Chrome e pesquisar SQL",
  "items": [
    {{"type": "open_app", "target": "chrome"}},
    {{"type": "search_website", "target": "google", "query": "sql"}}
  ],
  "answer": "Abrindo o Chrome e pesquisando SQL."
}}

Regras:
- Perguntas explicativas devem usar chat.
- Não execute ações apenas porque o usuário mencionou uma ação.
- Só execute se o usuário pedir claramente para executar.
- Se o usuário estiver perguntando sobre uma ação, use chat.
- Se o usuário disser para não pesquisar, nunca use search_website.
- Se o usuário pedir uma resposta direta, use chat.
- Se a informação exige dados atuais e o usuário não quer pesquisa, explique a limitação.
- Se for dúvida geral, use chat.
- Se for comando direto, use ação.
- Se estiver ambíguo, use chat e peça confirmação.
- Pesquisa, procura ou busca só devem usar search_website quando forem comandos explícitos.
- Em pesquisas, target e query devem ficar separados.
- Use targets limpos como google, youtube, github, wikipedia, alura ou linkedin.
- Não invente ações fora da lista.
- Se for conversa, use chat.
- Se for ação, use o tipo correto.
- Se uma observação anterior mostrar erro, corrija a decisão.
- Não tente mais de uma estratégia complexa.
- Seja objetivo.
- O campo "thought" deve ser curto e técnico.

Exemplos:
Usuário: "eles estavam falando sobre abrir o Google, eu não entendi"
Resposta:
{{
  "type": "chat",
  "thought": "usuario mencionou abrir Google como assunto, nao como comando",
  "answer": "Eles provavelmente queriam dizer acessar o site do Google no navegador. Não vou abrir nada; estou só explicando."
}}

Usuário: "não é para pesquisar"
Resposta:
{{
  "type": "chat",
  "thought": "usuario proibiu pesquisa",
  "answer": "Entendido. Não vou pesquisar. Vou responder apenas com o que eu já sei ou com o que está salvo na memória."
}}

Usuário: "me fala você em vez de pesquisar"
Resposta:
{{
  "type": "chat",
  "thought": "usuario quer resposta direta sem busca",
  "answer": "Claro. Vou responder sem pesquisar. Se for algo que depende de dados atualizados, eu vou avisar."
}}

Usuário: "qual é a população do Brasil?"
Resposta:
{{
  "type": "chat",
  "thought": "pergunta factual geral; responder sem executar acao",
  "answer": "A população do Brasil está na casa de centenas de milhões de habitantes. Para um número exato e atualizado, eu precisaria consultar uma fonte recente."
}}

Usuário atual:
{name}

Contexto:
{json.dumps(context, ensure_ascii=False)}

Histórico:
{json.dumps(history, ensure_ascii=False)}

Observação anterior:
{json.dumps(observation, ensure_ascii=False) if observation else "nenhuma"}

Mensagem do usuário:
{user_input}
""".strip()

        raw = self.client.generate(prompt)
        parsed = self._extract_json(raw)

        if not isinstance(parsed, dict):
            return {
                "type": "chat",
                "thought": "falha ao interpretar resposta do modelo",
                "answer": "Não consegui entender com segurança. Pode reformular?"
            }

        return parsed
