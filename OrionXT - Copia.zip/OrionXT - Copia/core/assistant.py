from core.agent import Agent
from core.handlers.execution_handler import ExecutionHandler
from core.handlers.memory_handler import MemoryHandler
from core.handlers.mode_handler import (
    ModeHandler,
    is_activate_orion_command,
    is_deactivate_orion_command,
    is_orion_mode_command,
)
from core.handlers.name_handler import NameHandler
from core.handlers.study_handler import StudyHandler
from core.memory import Memory
from core.modes import ModeManager
from core.permission_gate import PermissionGate
from core.response_generator import ResponseGenerator
from core.router import Router
from core.validator import Validator


class Assistant:
    def __init__(
        self,
        agent: Agent,
        router: Router,
        memory: Memory,
        mode_manager: ModeManager | None = None,
        memory_store=None,
        context_engine=None,
        conversation_guard=None,
        intent_interpreter=None,
        response_generator=None,
        permission_gate=None,
    ):
        self.agent = agent
        self.router = router
        self.memory = memory
        self.validator = Validator()
        self.mode_manager = mode_manager if mode_manager is not None else ModeManager()
        self.memory_store = memory_store
        self.context_engine = context_engine
        self.conversation_guard = conversation_guard
        self.intent_interpreter = intent_interpreter
        self.response_generator = response_generator or ResponseGenerator(getattr(agent, "client", None))
        self.permission_gate = permission_gate or PermissionGate()

        self.name_handler = NameHandler(self.memory)
        self.mode_handler = ModeHandler(self.mode_manager)
        self.memory_handler = MemoryHandler(self.memory, self.memory_store)
        self.study_handler = StudyHandler(self.memory_handler)
        self.execution_handler = ExecutionHandler(
            router=self.router,
            validator=self.validator,
            permission_gate=self.permission_gate,
            response_generator=self.response_generator,
            response_context_provider=self._response_context,
        )

    def _save_interaction_event(self, user_input: str, answer: str):
        if self.memory_store is None:
            return

        try:
            self.memory_store.save_event(
                event_type="interaction",
                content=f"USER: {user_input}\nORION: {answer}",
                importance=1,
                metadata={
                    "user_input": user_input,
                    "assistant_response": answer,
                },
            )
        except Exception as exc:
            print("Erro ao salvar evento no banco:", repr(exc))

    def _record_interaction(self, user_input: str, answer: str):
        self.memory.add_history(user_input, answer)
        self._save_interaction_event(user_input, answer)

    def handle(self, user_input: str) -> str:
        name_answer = self.name_handler.handle(user_input)
        if name_answer is not None:
            self._record_interaction(user_input, name_answer)
            return name_answer

        mode_answer = self.mode_handler.handle(user_input)
        if mode_answer is not None:
            self._record_interaction(user_input, mode_answer)
            return mode_answer

        if self.conversation_guard is not None:
            try:
                guarded_response = self.conversation_guard.handle(user_input)
            except Exception as exc:
                print("Erro no Conversation Guard:", repr(exc))
                guarded_response = None

            if guarded_response:
                answer = self._generate_final_response(
                    user_input=user_input,
                    interpretation={"intent": "chat", "domain": "system"},
                    response_type="blocked",
                    success=False,
                    fallback=guarded_response,
                )
                self._record_interaction(user_input, answer)
                return answer

        if self.intent_interpreter is not None:
            interpretation = self.intent_interpreter.interpret(user_input)
            answer = self._handle_interpretation(user_input, interpretation)
            self._record_interaction(user_input, answer)
            return answer

        return self._handle_legacy_flow(user_input)

    def _handle_interpretation(self, user_input: str, interpretation: dict) -> str:
        intent = interpretation.get("intent", "clarify")

        if intent == "ask_memory":
            return self.memory_handler.handle_ask_memory(interpretation)

        if intent == "save_memory":
            return self.memory_handler.handle_save_memory(interpretation, user_input=user_input)

        if intent == "update_preference":
            return self.memory_handler.handle_update_preference(interpretation)

        if intent == "study_strategy":
            return self.study_handler.handle_study_strategy(interpretation)

        if intent == "chat":
            context_response = self._try_context_engine(user_input)
            if context_response:
                return context_response

            return self.agent.generate_chat_answer(
                user_input,
                context_hint=interpretation.get("answer_hint", ""),
            )

        if intent == "clarify":
            context_response = self._try_context_engine(user_input)
            if context_response:
                return context_response

            return self._generate_final_response(
                user_input=user_input,
                interpretation=interpretation,
                response_type="clarify",
                success=False,
                fallback="Não consegui entender com segurança. Você quer que eu converse, pesquise ou execute alguma ação?",
            )

        if intent in {"execute_action", "search_web"}:
            decision = self.execution_handler.build_decision_from_interpretation(interpretation)

            if decision is None:
                return self._generate_final_response(
                    user_input=user_input,
                    interpretation=interpretation,
                    response_type="clarify",
                    success=False,
                    fallback="Não consegui entender com segurança qual ação você quer executar. Pode reformular?",
                )

            return self.execution_handler.execute_decision(
                user_input,
                decision,
                interpretation=interpretation,
            )

        return self.agent.generate_chat_answer(user_input)

    def _try_context_engine(self, user_input: str) -> str | None:
        if self.context_engine is None:
            return None

        try:
            return self.context_engine.handle(user_input)
        except Exception as exc:
            print("Erro no Context Engine:", repr(exc))
            return None

    def _response_context(self) -> dict:
        context = {}

        try:
            context["memory_context"] = self.memory.get_context()
        except Exception:
            context["memory_context"] = {}

        try:
            context["recent_history"] = self.memory.data.get("history", [])[-3:]
        except Exception:
            context["recent_history"] = []

        return context

    def _generate_final_response(
        self,
        user_input: str,
        interpretation: dict | None = None,
        decision: dict | None = None,
        observation=None,
        success: bool | None = None,
        response_type: str = "action_result",
        fallback: str = "",
        error: str = "",
    ) -> str:
        return self.execution_handler.generate_final_response(
            user_input=user_input,
            interpretation=interpretation,
            decision=decision,
            observation=observation,
            success=success,
            response_type=response_type,
            fallback=fallback,
            error=error,
        )

    def _handle_legacy_flow(self, user_input: str) -> str:
        context_response = self._try_context_engine(user_input)
        if context_response:
            self._record_interaction(user_input, context_response)
            return context_response

        decision = self.agent.decide(user_input)
        answer = self.execution_handler.execute_decision(user_input, decision)
        self._record_interaction(user_input, answer)
        return answer

    def _execute_decision(self, user_input: str, decision: dict, interpretation: dict | None = None) -> str:
        return self.execution_handler.execute_decision(user_input, decision, interpretation=interpretation)

    def _build_decision_from_interpretation(self, interpretation: dict) -> dict | None:
        return self.execution_handler.build_decision_from_interpretation(interpretation)
