import threading


IDLE = "idle"
LISTENING = "listening"
TRANSCRIBING = "transcribing"
THINKING = "thinking"
SPEAKING = "speaking"
INTERRUPTED = "interrupted"


class RuntimeState:
    def __init__(self):
        self._lock = threading.RLock()
        self._state = IDLE

    def set(self, state: str):
        with self._lock:
            self._state = state

    def get(self) -> str:
        with self._lock:
            return self._state

    def is_state(self, state: str) -> bool:
        return self.get() == state


runtime_state = RuntimeState()
