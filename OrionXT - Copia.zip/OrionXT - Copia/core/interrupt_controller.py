import ctypes
import threading
import time
from collections.abc import Callable


class InterruptController:
    def __init__(self):
        self._lock = threading.RLock()
        self._interrupted = threading.Event()
        self._speaking = threading.Event()
        self._stop_current_speech: Callable[[], bool] | None = None
        self._clear_speech_queue: Callable[[], int] | None = None
        self._keyboard_thread: threading.Thread | None = None
        self._keyboard_stop = threading.Event()

    def register_tts_handlers(
        self,
        stop_current_speech: Callable[[], bool] | None = None,
        clear_speech_queue: Callable[[], int] | None = None,
    ):
        with self._lock:
            self._stop_current_speech = stop_current_speech
            self._clear_speech_queue = clear_speech_queue

    def request_interrupt(self) -> bool:
        with self._lock:
            was_speaking = self._speaking.is_set()
            clear_queue = self._clear_speech_queue
            stop_current = self._stop_current_speech
            self._interrupted.set()

        cleared = 0
        stopped = False

        if clear_queue is not None:
            try:
                cleared = clear_queue()
            except Exception as exc:
                print("Erro ao limpar fila de fala:", repr(exc))

        if stop_current is not None:
            try:
                stopped = bool(stop_current())
            except Exception as exc:
                print("Erro ao parar fala atual:", repr(exc))

        return bool(was_speaking or cleared or stopped)

    def clear_interrupt(self):
        self._interrupted.clear()

    def is_interrupted(self) -> bool:
        return self._interrupted.is_set()

    def set_speaking(self, value: bool):
        if value:
            self._speaking.set()
        else:
            self._speaking.clear()

    def is_speaking(self) -> bool:
        return self._speaking.is_set()

    def stop_current_speech(self) -> bool:
        with self._lock:
            stop_current = self._stop_current_speech

        if stop_current is None:
            return False

        try:
            return bool(stop_current())
        except Exception as exc:
            print("Erro ao parar fala atual:", repr(exc))
            return False

    def clear_speech_queue(self) -> int:
        with self._lock:
            clear_queue = self._clear_speech_queue

        if clear_queue is None:
            return 0

        try:
            return int(clear_queue() or 0)
        except Exception as exc:
            print("Erro ao limpar fila de fala:", repr(exc))
            return 0

    def start_keyboard_monitor(
        self,
        on_interrupt: Callable[[bool], None] | None = None,
        poll_interval: float = 0.05,
    ) -> bool:
        if self._keyboard_thread and self._keyboard_thread.is_alive():
            return True

        user32 = self._user32()
        if user32 is None:
            return False

        self._keyboard_stop.clear()
        self._keyboard_thread = threading.Thread(
            target=self._keyboard_loop,
            args=(user32, on_interrupt, poll_interval),
            daemon=True,
        )
        self._keyboard_thread.start()
        return True

    def stop_keyboard_monitor(self):
        self._keyboard_stop.set()

    def _keyboard_loop(self, user32, on_interrupt, poll_interval: float):
        esc_was_down = False
        ctrl_space_was_down = False

        while not self._keyboard_stop.is_set():
            esc_down = self._key_down(user32, 0x1B)
            ctrl_down = self._key_down(user32, 0x11)
            space_down = self._key_down(user32, 0x20)
            ctrl_space_down = ctrl_down and space_down

            if (esc_down and not esc_was_down) or (ctrl_space_down and not ctrl_space_was_down):
                interrupted = self.request_interrupt()
                if on_interrupt is not None:
                    try:
                        on_interrupt(interrupted)
                    except Exception as exc:
                        print("Erro no callback de interrupção:", repr(exc))

            esc_was_down = esc_down
            ctrl_space_was_down = ctrl_space_down
            time.sleep(max(0.02, poll_interval))

    def _user32(self):
        windll = getattr(ctypes, "windll", None)
        if windll is None:
            return None

        try:
            return windll.user32
        except Exception:
            return None

    def _key_down(self, user32, key_code: int) -> bool:
        try:
            return bool(user32.GetAsyncKeyState(key_code) & 0x8000)
        except Exception:
            return False


interrupt_controller = InterruptController()
