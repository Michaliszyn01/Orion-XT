import re

from core.utils import normalize_text


SEARCH_BLOCK_PATTERNS = (
    "nao pesquisa",
    "nao pesquise",
    "nao quero que pesquise",
    "nao e para pesquisar",
    "nao e pra pesquisar",
    "nao era pra pesquisar",
    "pare de pesquisar",
    "para de pesquisar",
    "pesquisando sem minha autorizacao",
    "sem minha autorizacao",
    "por que voce esta pesquisando",
    "porque voce esta pesquisando",
    "voce esta pesquisando sem",
    "nao busca",
    "nao procure",
)

SEARCH_SOFT_BLOCK_PATTERNS = (
    "sem pesquisar",
    "em vez de pesquisar",
    "inves de pesquisar",
)

ACTION_BLOCK_PATTERNS = (
    "nao execute",
    "nao executa",
    "nao faca isso",
    "nao faz isso",
    "nao abre",
    "nao abre nada",
    "nao abra",
    "nao abra nada",
    "nao abrir",
    "nao quero que abra",
    "nao e para abrir",
    "nao e pra abrir",
    "pare de fazer isso",
    "para de fazer isso",
)

ACTION_TOPIC_PATTERNS = (
    "falando sobre abrir",
    "falaram sobre abrir",
    "eles estavam falando sobre abrir",
    "me explicaram sobre pesquisar",
    "falando sobre pesquisar",
    "nao entendi o que significa abrir",
    "nao entendi o que significa pesquisar",
    "o que significa abrir",
    "o que significa pesquisar",
    "como funciona abrir",
    "como funciona pesquisar",
    "como eu abro",
    "como abrir",
    "me ensina a pesquisar",
    "me ensina a abrir",
)


def _contains_any(text: str, patterns: tuple[str, ...]) -> bool:
    normalized = normalize_text(text)
    return any(pattern in normalized for pattern in patterns)


def forbids_search(text: str, include_soft: bool = False) -> bool:
    patterns = SEARCH_BLOCK_PATTERNS

    if include_soft:
        patterns = patterns + SEARCH_SOFT_BLOCK_PATTERNS

    return _contains_any(text, patterns)


def forbids_action(text: str) -> bool:
    return _contains_any(text, ACTION_BLOCK_PATTERNS)


def action_mentioned_as_topic(text: str) -> bool:
    return _contains_any(text, ACTION_TOPIC_PATTERNS)


def explicit_search_requested(text: str) -> bool:
    text = normalize_text(text)

    if forbids_search(text, include_soft=True) or action_mentioned_as_topic(text):
        return False

    command_starts = (
        "pesquisa ",
        "pesquisar ",
        "pesquise ",
        "procura ",
        "procurar ",
        "procure ",
        "busca ",
        "buscar ",
        "busque ",
        "agora pesquisa ",
        "agora procura ",
        "agora busca ",
    )

    if text.startswith(command_starts):
        return True

    return bool(
        re.search(
            r"\b(e|agora|orion|orionxt|por favor|pode|voce pode)\s+"
            r"(pesquisar|pesquise|pesquisa|procurar|procure|procura|buscar|busque|busca)\b",
            text,
        )
    )
