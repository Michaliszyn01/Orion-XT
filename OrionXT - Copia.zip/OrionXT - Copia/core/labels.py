from core.utils import normalize_text


DISPLAY_TARGET_LABELS = {
    "google": "Google",
    "youtube": "YouTube",
    "github": "GitHub",
    "wikipedia": "Wikipedia",
    "alura": "Alura",
    "linkedin": "LinkedIn",
    "gmail": "Gmail",
    "chatgpt": "ChatGPT",
    "netflix": "Netflix",
    "chrome": "Chrome",
    "edge": "Edge",
    "firefox": "Firefox",
    "vscode": "VS Code",
    "spotify": "Spotify",
    "discord": "Discord",
    "notion": "Notion",
    "steam": "Steam",
    "excel": "Excel",
    "word": "Word",
    "notepad": "Bloco de Notas",
    "calculadora": "Calculadora",
    "explorador": "Explorador de Arquivos",
    "gerenciador de tarefas": "Gerenciador de Tarefas",
    "cmd": "Prompt de Comando",
    "powershell": "PowerShell",
    "configuracoes": "Configuracoes",
    "downloads": "Downloads",
    "documentos": "Documentos",
    "desktop": "Desktop",
    "imagens": "Imagens",
    "videos": "Videos",
    "musicas": "Musicas",
    "orionxt": "OrionXT",
}


def display_target(target: str, fallback: str = "destino") -> str:
    raw_target = str(target or "").strip()

    if not raw_target:
        return fallback

    return DISPLAY_TARGET_LABELS.get(normalize_text(raw_target), raw_target)
