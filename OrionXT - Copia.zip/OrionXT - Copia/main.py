import time

from config.voice_config import (
    MAX_RECORDING_DURATION,
    MIN_RECORDING_DURATION,
    PRE_SPEECH_TIMEOUT,
    REPROMPT_ON_EMPTY_AUDIO,
    SAMPLE_RATE,
    SILENCE_DURATION,
    SILENCE_THRESHOLD,
    STT_LANGUAGE,
    STT_MODEL_SIZE,
)
from providers.ollama_client import OllamaClient
from core.interrupt_controller import interrupt_controller
from core.memory import Memory
from core.agent import Agent
from core.conversation_guard import ConversationGuard
from core.context_engine import ContextEngine
from core.intent_interpreter import IntentInterpreter
from core.router import Router
from core.assistant import Assistant
from core.modes import ModeManager
from core.runtime_state import (
    IDLE,
    INTERRUPTED,
    LISTENING,
    SPEAKING,
    THINKING,
    TRANSCRIBING,
    runtime_state,
)
from storage.memory_store import MemoryStore
from voice.normalizer import normalize_voice_text
from voice.stt import (
    LISTEN_STATUS_EMPTY_TRANSCRIPT,
    LISTEN_STATUS_ERROR,
    LISTEN_STATUS_NO_SPEECH,
    LISTEN_STATUS_TOO_SHORT,
    SpeechToText,
)
from voice.tts import is_speaking, speak


def _print_interrupt_status(interrupted: bool):
    runtime_state.set(INTERRUPTED if interrupted else runtime_state.get())

    if interrupted:
        print("\nOrionXT: Fala interrompida.")
    else:
        print("\nOrionXT: Nenhuma fala em andamento.")


def _set_voice_status(status: str):
    labels = {
        LISTENING: "Ouvindo...",
        TRANSCRIBING: "Transcrevendo...",
        THINKING: "Pensando...",
        SPEAKING: "Falando...",
        IDLE: "Pronto.",
    }
    runtime_state.set(status)
    label = labels.get(status)

    if label:
        print(f"OrionXT: {label}")


def _handle_empty_voice_result(stt: SpeechToText) -> bool:
    result = stt.last_result

    if result.status == LISTEN_STATUS_NO_SPEECH:
        print("OrionXT: Nenhuma fala detectada.")
        _set_voice_status(IDLE)
        return True

    if result.status == LISTEN_STATUS_TOO_SHORT:
        message = "Pode repetir? O áudio ficou muito curto."
        if REPROMPT_ON_EMPTY_AUDIO:
            print(f"OrionXT: {message}")
        else:
            print("OrionXT: Áudio curto ou ruído ignorado.")
        _set_voice_status(IDLE)
        return True

    if result.status == LISTEN_STATUS_EMPTY_TRANSCRIPT:
        print("OrionXT: Não entendi uma fala clara. Pode repetir?")
        _set_voice_status(IDLE)
        return True

    if result.status == LISTEN_STATUS_ERROR or stt.last_error:
        print(f"OrionXT: {stt.last_error or result.message}")
        _set_voice_status(IDLE)
        return True

    return False


def main():
    memory = Memory()
    client = OllamaClient()

    agent = Agent(client, memory)
    router = Router(memory)
    mode_manager = ModeManager()
    memory_store = MemoryStore()
    context_engine = ContextEngine(memory_store)
    conversation_guard = ConversationGuard(memory_store)
    intent_interpreter = IntentInterpreter(client, memory, memory_store)
    assistant = Assistant(
        agent,
        router,
        memory,
        mode_manager,
        memory_store,
        context_engine,
        conversation_guard,
        intent_interpreter,
    )

    stt = SpeechToText(model_size=STT_MODEL_SIZE, language=STT_LANGUAGE)

    print("OrionXT iniciado.")
    print("Digite uma mensagem ou aperte Enter vazio para falar.")
    print("Aperte ESC ou Ctrl+Espaço para parar a fala atual.")
    print("Digite 'sair' para encerrar.")

    keyboard_monitor_enabled = interrupt_controller.start_keyboard_monitor(
        on_interrupt=_print_interrupt_status,
    )

    if not keyboard_monitor_enabled:
        print("OrionXT: Hotkey de interrupção indisponível neste ambiente.")

    try:
        while True:
            typed_input = input("Você: ").strip()

            if typed_input.lower() in ["sair", "exit", "quit"]:
                print("OrionXT: Até mais.")
                break

            if typed_input:
                user_input = typed_input
            else:
                while is_speaking():
                    time.sleep(0.05)

                if runtime_state.is_state(INTERRUPTED):
                    time.sleep(0.15)
                    runtime_state.set(IDLE)

                user_input = stt.listen(
                    samplerate=SAMPLE_RATE,
                    max_duration=MAX_RECORDING_DURATION,
                    silence_threshold=SILENCE_THRESHOLD,
                    silence_duration=SILENCE_DURATION,
                    min_recording_duration=MIN_RECORDING_DURATION,
                    pre_speech_timeout=PRE_SPEECH_TIMEOUT,
                    status_callback=_set_voice_status,
                )

                if user_input:
                    original_input = user_input
                    user_input = normalize_voice_text(user_input)

                    if original_input != user_input:
                        print(f"Você disse: {original_input}")
                        print(f"Corrigido para: {user_input}")
                    else:
                        print(f"Você disse: {user_input}")
                elif _handle_empty_voice_result(stt):
                    continue

            if not user_input:
                _set_voice_status(IDLE)
                continue

            _set_voice_status(THINKING)
            response = assistant.handle(user_input)
            print(f"OrionXT: {response}")
            _set_voice_status(SPEAKING)
            speak(response)
    finally:
        interrupt_controller.stop_keyboard_monitor()


if __name__ == "__main__":
    main()
