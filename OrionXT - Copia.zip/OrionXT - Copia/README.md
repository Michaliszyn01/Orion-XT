# OrionXT

OrionXT é um assistente pessoal local para Windows, desenvolvido em Python, com foco em automação, voz, memória e interpretação de comandos.

O objetivo do projeto é criar um assistente estilo Jarvis, mas com uma arquitetura leve, modular e prática, capaz de executar ações no computador, responder perguntas, lembrar informações importantes e auxiliar em tarefas do dia a dia.

---

## Status do projeto

**Versão atual:** `v0.6`

**Status:** Protótipo funcional em desenvolvimento.

Nesta versão, o OrionXT já possui interpretação de comandos, execução de ações, entrada e saída por voz, normalização de erros comuns do STT, Modo Orion, memória em JSON, memória estruturada com SQLite e testes automatizados.

---

## Funcionalidades atuais

- Interpretação de comandos por texto
- Entrada por voz com STT
- Resposta por voz com TTS natural
- Fila de TTS para evitar falas sobrepostas
- Normalização de erros comuns da fala
- Abertura de aplicativos
- Fechamento de aplicativos
- Abertura de sites
- Pesquisa em sites
- Abertura de pastas
- Execução de múltiplas ações
- Modo Orion com música tema no Spotify
- Memória curta em JSON
- Memória estruturada com SQLite
- Testes automatizados para comandos principais

---

## Arquitetura

Fluxo principal do OrionXT:

```txt
Usuário
↓
Texto ou voz
↓
Normalizador de voz
↓
Assistant
↓
Agent
↓
Validator
↓
Router
↓
Ações / Resposta
↓
Memória
↓
TTS

Principais pastas do projeto:

actions/      Ações executadas no sistema
core/         Lógica principal do assistente
registry/     Registro de apps, sites e pastas suportados
storage/      Banco SQLite e memória estruturada
voice/        STT, TTS e normalização de voz
tests/        Testes automatizados
data/         Arquivos locais de memória
Tecnologias usadas
Python
SQLite
Ollama
Gemma 3 4B
Faster Whisper
Edge TTS
SoundDevice
NumPy
SciPy
Requests
Requisitos

Antes de executar o projeto, é necessário ter:

Python instalado
Ollama instalado
Modelo gemma3:4b disponível no Ollama
Microfone funcional no Windows

Modelo usado atualmente:

ollama run gemma3:4b
Instalação

Na pasta do projeto, instale as dependências:

pip install -r requirements.txt

Ou, se estiver usando o launcher do Python no Windows:

py -m pip install -r requirements.txt
Como executar

Na pasta do projeto, rode:

py main.py

Depois disso:

Digite uma mensagem normalmente; ou
Aperte Enter vazio para falar pelo microfone; ou
Digite sair para encerrar.
Exemplos de comandos
abre o google
abra o youtube
pesquisa no youtube aula de python
pesquisa na alura power bi
abre o vscode
fecha o spotify
abre downloads
abre o chrome e pesquisa sql
me explica o que é programação
modo orion
sair
Modo Orion

O Modo Orion é um modo especial de ativação do assistente.

Comando principal:

modo orion

Frase de ativação:

Modo Orion ativado. Estou online e pronto para operar.

Música tema atual:

KISS - I Was Made for Lovin' You

O modo abre a música no Spotify e altera o estado interno do assistente para orion.

Memória

O OrionXT usa dois tipos de memória.

Memória JSON

Usada para contexto rápido:

Nome do usuário
Histórico curto
Último site aberto
Última ação executada
Última pesquisa feita

Arquivo:

data/memory.json
Memória SQLite

Usada para memória estruturada:

Eventos
Preferências
Memória curta
Memória longa
Progresso de estudo
Metas
Correções de voz

Banco local:

data/orion.db

Tabelas principais:

events
goals
long_term_memory
preferences
short_term_memory
study_progress
subjects
voice_corrections
Testes

Rodar testes principais:

py tests/test_orionxt.py

Rodar teste da memória SQLite:

py tests/test_memory_store.py

Rodar teste de voz:

py tests/teste_tts.py

Resultado atual dos testes principais:

Total: 57
Sucesso: 57
Erro: 0
Taxa de acerto: 100%
Segurança e validação

Antes de executar ações, o OrionXT valida se:

O tipo de ação é permitido
O aplicativo existe no registry
O site existe no registry
A pasta existe no registry
A pesquisa possui alvo e consulta
A ação não foi inventada pela IA

Isso reduz erros como tentar abrir aplicativos não configurados ou executar ações fora do escopo.

Normalização de voz

O OrionXT possui uma camada simples para corrigir erros comuns do STT.

Exemplos:

gugou → google
iutube → youtube
giti rab → github
lura → alura
mado orion → modo orion
moto orion → modo orion
modo audio → modo orion

Essa camada não decide ações. Ela apenas limpa ruídos comuns da transcrição antes de enviar o texto para o assistente.

Roadmap

Próximos passos planejados:

Criar Context Engine focado em estudos
Fazer o Orion entender contexto atual de estudo
Registrar dificuldades e aprendizados
Usar SQLite para respostas mais contextuais
Criar cache de TTS para frases comuns
Melhorar logs e tratamento de erros
Criar documentação técnica da arquitetura
Preparar vídeo demo do projeto
Futuramente estudar wake word e visão de tela
Filosofia do projeto

O OrionXT segue uma ideia de arquitetura IA-first:

A IA interpreta e decide.
O Python executa ações, valida segurança e gerencia ferramentas.
O banco de dados guarda memória estruturada.
O sistema deve ser modular, leve e expansível.

O foco não é criar um sistema cheio de regras rígidas, mas sim um assistente pessoal com boa interpretação, contexto, memória e segurança.