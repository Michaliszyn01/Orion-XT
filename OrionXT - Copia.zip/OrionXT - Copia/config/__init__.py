"""Configurações do OrionXT."""
