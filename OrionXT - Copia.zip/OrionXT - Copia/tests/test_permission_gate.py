from pathlib import Path
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.permission_gate import PermissionGate


TEST_CASES = [
    {
        "name": "abre o google",
        "user_input": "abre o google",
        "decision": {"type": "open_website", "target": "google"},
        "allowed": True,
    },
    {
        "name": "abre o youtube",
        "user_input": "abre o youtube",
        "decision": {"type": "open_website", "target": "youtube"},
        "allowed": True,
    },
    {
        "name": "abre a pasta downloads",
        "user_input": "abre a pasta downloads",
        "decision": {"type": "open_folder", "target": "downloads"},
        "allowed": True,
    },
    {
        "name": "pesquisa no youtube aula de python",
        "user_input": "pesquisa no youtube aula de python",
        "decision": {"type": "search_website", "target": "youtube", "query": "aula de python"},
        "allowed": True,
    },
    {
        "name": "fecha o spotify",
        "user_input": "fecha o spotify",
        "decision": {"type": "close_app", "target": "spotify"},
        "allowed": True,
    },
    {
        "name": "nao fecha explorador",
        "user_input": "fecha o explorador",
        "decision": {"type": "close_app", "target": "explorador"},
        "allowed": False,
        "reason_contains": "sensível",
    },
    {
        "name": "eles falaram sobre abrir",
        "user_input": "eles estavam falando sobre abrir o google, eu não entendi",
        "decision": {"type": "open_website", "target": "google"},
        "allowed": False,
        "reason_contains": "assunto",
    },
    {
        "name": "como abre o google",
        "user_input": "como abre o google?",
        "decision": {"type": "open_website", "target": "google"},
        "allowed": False,
        "reason_contains": "assunto",
    },
    {
        "name": "nao abre nada",
        "user_input": "não abre nada",
        "decision": {"type": "open_website", "target": "google"},
        "allowed": False,
        "reason_contains": "não executar",
    },
    {
        "name": "nao e para pesquisar",
        "user_input": "não é para pesquisar",
        "decision": {"type": "search_website", "target": "google", "query": "python"},
        "allowed": False,
        "reason_contains": "não pesquisar",
    },
    {
        "name": "abre isso",
        "user_input": "abre isso",
        "decision": {"type": "open_website", "target": "google"},
        "allowed": False,
        "reason_contains": "não ficou claro",
    },
    {
        "name": "fecha ele",
        "user_input": "fecha ele",
        "decision": {"type": "close_app", "target": "spotify"},
        "allowed": False,
        "requires_confirmation": True,
        "reason_contains": "qual aplicativo",
    },
    {
        "name": "pesquisa aquilo",
        "user_input": "pesquisa aquilo",
        "decision": {"type": "search_website", "target": "google", "query": "aquilo"},
        "allowed": False,
        "reason_contains": "o que",
    },
    {
        "name": "pensando em pesquisar",
        "user_input": "eu estava pensando em pesquisar python",
        "decision": {"type": "search_website", "target": "google", "query": "python"},
        "allowed": False,
        "reason_contains": "pedido claro",
    },
    {
        "name": "multi claro",
        "user_input": "abre o google e pesquisa python",
        "decision": {
            "type": "multi_action",
            "items": [
                {"type": "open_website", "target": "google"},
                {"type": "search_website", "target": "google", "query": "python"},
            ],
        },
        "allowed": True,
    },
    {
        "name": "multi ambiguo",
        "user_input": "abre isso e fecha ele",
        "decision": {
            "type": "multi_action",
            "items": [
                {"type": "open_website", "target": "google"},
                {"type": "close_app", "target": "spotify"},
            ],
        },
        "allowed": False,
        "reason_contains": "sequência",
    },
]


def run_case(gate: PermissionGate, case: dict) -> bool:
    result = gate.check(
        user_input=case["user_input"],
        decision=case["decision"],
        validation_result=(True, ""),
    )
    allowed = bool(result.get("allowed"))
    requires_confirmation = bool(result.get("requires_confirmation"))
    reason = str(result.get("reason") or "")

    success = allowed is case["allowed"]
    error = "success"

    if "requires_confirmation" in case and requires_confirmation is not case["requires_confirmation"]:
        success = False
        error = "confirmation_mismatch"

    if case.get("reason_contains") and case["reason_contains"].lower() not in reason.lower():
        success = False
        error = "wrong_reason"

    print(f"[TESTE] {case['name']}")
    print(f"Permitido: {allowed}")
    print(f"Requer confirmação: {requires_confirmation}")
    print(f"Motivo: {reason or '-'}")
    print(f"STATUS: {'SUCESSO' if success else 'ERRO'}")
    print(f"TIPO DE ERRO: {error}")
    print("-" * 40)

    return success


if __name__ == "__main__":
    gate = PermissionGate()
    results = [run_case(gate, case) for case in TEST_CASES]
    success_count = sum(1 for result in results if result)
    total = len(results)

    print("RESUMO:")
    print(f"Total: {total}")
    print(f"Sucesso: {success_count}")
    print(f"Erro: {total - success_count}")

    raise SystemExit(0 if success_count == total else 1)
