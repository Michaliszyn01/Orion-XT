from datetime import datetime


class InMemoryMemoryStore:
    def __init__(self):
        self.events = []
        self.short_term = []
        self.long_term = []
        self.preferences = {}
        self._next_id = 1

    def save_event(self, event_type: str, content: str, importance: int = 1, metadata: dict | None = None):
        self.events.append(self._row({
            "event_type": event_type,
            "category": event_type,
            "content": content,
            "importance": importance,
            "metadata": metadata or {},
            "_source": "events",
        }))

    def save_short_memory(
        self,
        category: str,
        content: str,
        importance: int = 1,
        metadata: dict | None = None,
    ):
        self.short_term.append(self._row({
            "category": category,
            "content": content,
            "value": content,
            "importance": importance,
            "metadata": metadata or {},
            "_source": "short_term_memory",
        }))

    def save_long_memory(
        self,
        category: str,
        key: str,
        value: str,
        importance: int = 1,
        metadata: dict | None = None,
    ):
        for row in self.long_term:
            if row.get("category") == category and row.get("key") == key:
                row.update({
                    "value": value,
                    "content": value,
                    "importance": importance,
                    "metadata": metadata or {},
                    "updated_at": self._now(),
                })
                return

        self.long_term.append(self._row({
            "category": category,
            "key": key,
            "memory_key": key,
            "name": key,
            "value": value,
            "content": value,
            "importance": importance,
            "metadata": metadata or {},
            "_source": "long_term_memory",
        }))

    def get_recent_events(self, limit: int = 10):
        return list(reversed(self.events))[: self._clean_limit(limit)]

    def get_relevant_memories(self, category: str | None = None, limit: int = 10):
        rows = self.long_term + self.short_term

        if category:
            rows = [row for row in rows if row.get("category") == category]

        rows = sorted(
            rows,
            key=lambda row: (int(row.get("importance") or 0), row.get("updated_at") or row.get("created_at") or ""),
            reverse=True,
        )
        return [dict(row) for row in rows[: self._clean_limit(limit)]]

    def get_preferences(self):
        return dict(self.preferences)

    def set_preference(self, key: str, value: str):
        self.preferences[key] = value

    def _row(self, data: dict) -> dict:
        now = self._now()
        row = {
            "id": self._next_id,
            "created_at": now,
            "updated_at": now,
        }
        row.update(data)
        self._next_id += 1
        return row

    def _now(self) -> str:
        return datetime.now().isoformat(timespec="seconds")

    def _clean_limit(self, limit: int) -> int:
        try:
            return max(1, int(limit))
        except (TypeError, ValueError):
            return 10
