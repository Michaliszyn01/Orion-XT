from __future__ import annotations

import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.agent import Agent
from core.assistant import Assistant
from core.conversation_guard import ConversationGuard
from core.intent_interpreter import IntentInterpreter
from core.modes import ModeManager
from core.observation import Observation
from core.utils import normalize_text
from fakes import InMemoryMemoryStore


class TestMemory:
    def __init__(self):
        self.data = {
            "name": "",
            "preferences": {},
            "history": [],
            "context": {
                "last_website": "",
                "last_action": "",
                "last_query": "",
            },
        }

    def add_history(self, user_message: str, assistant_message: str):
        self.data["history"].append({
            "user": user_message,
            "assistant": assistant_message,
        })

    def set_name(self, name: str):
        self.data["name"] = name

    def get_name(self):
        return self.data.get("name", "")

    def get_context(self):
        return self.data.get("context", {})

    def set_context(self, last_website=None, last_action=None, last_query=None):
        context = self.data.setdefault("context", {})
        if last_website is not None:
            context["last_website"] = last_website
        if last_action is not None:
            context["last_action"] = last_action
        if last_query is not None:
            context["last_query"] = last_query

    def save(self):
        pass


class FakeChatClient:
    def generate(self, prompt: str) -> str:
        normalized = normalize_text(prompt)

        if (
            "abrir o google" in normalized
            and ("falando sobre" in normalized or "nao entendi o que significa" in normalized)
        ):
            return "Eles provavelmente queriam dizer acessar o site do Google no navegador. Não vou abrir nada; estou só explicando."

        if "populacao do brasil" in normalized:
            return "A população do Brasil está na casa de centenas de milhões de habitantes. Para um número exato e atualizado, eu precisaria consultar uma fonte recente."

        if "em vez de pesquisar" in normalized or "inves de pesquisar" in normalized:
            return "Claro. Vou responder sem pesquisar. Se depender de dados atualizados, eu vou avisar."

        if "notas de corte" in normalized:
            return "Sem pesquisar dados atualizados, eu não consigo garantir as notas de corte reais. Posso usar suas notas salvas para montar uma estratégia, mas para nota de corte exata preciso consultar uma fonte atualizada."

        return "Entendi. Vou responder sem executar nenhuma ação."


class FakeIntentClient:
    def generate(self, prompt: str) -> str:
        match = re.search(r"Mensagem do usuário:\s*(.+)\s*$", prompt, re.DOTALL)
        text = match.group(1).strip() if match else ""
        normalized = normalize_text(text).strip(" .?!,;:-")

        responses = {
            "abre o google": self._action("execute_action", "web", "open_website", "google"),
            "abre o youtube": self._action("execute_action", "web", "open_website", "youtube"),
            "abre a pasta downloads": self._action("execute_action", "folder", "open_folder", "downloads"),
            "pesquisa no youtube aula de python": self._search("youtube", "aula de python"),
            "fecha o spotify": self._action("execute_action", "app", "close_app", "spotify"),
            "abre o vscode": self._action("execute_action", "app", "open_app", "vscode"),
            "como abre o google": self._action("execute_action", "web", "open_website", "google"),
            "abre isso": self._action("execute_action", "web", "open_website", "google"),
            "fecha ele": self._action("execute_action", "app", "close_app", "spotify"),
            "pesquisa aquilo": self._search("google", "aquilo"),
            "eu estava pensando em pesquisar python": self._search("google", "python"),
            "abre o google e pesquisa python": self._multi([
                {"type": "open_website", "target": "google"},
                {"type": "search_website", "target": "google", "query": "python"},
            ]),
            "abre isso e fecha ele": self._multi([
                {"type": "open_website", "target": "google"},
                {"type": "close_app", "target": "spotify"},
            ]),
            "eles estavam falando sobre abrir o google, eu nao entendi": self._chat("general", "Explicar sem abrir nada"),
            "nao entendi o que significa abrir o google": self._chat("general", "Explicar sem abrir nada"),
            "qual e a populacao do brasil": self._chat("general", "Responder com limitação de dados atuais"),
            "o que eu preciso estudar para melhorar minhas notas": {
                "intent": "study_strategy",
                "domain": "academic",
                "confidence": 0.92,
                "should_execute": False,
                "should_search": False,
                "action_type": "",
                "target": "",
                "query": "",
                "entities": {},
                "answer_hint": "Gerar estratégia com notas salvas",
            },
            "qual curso eu quero fazer": self._memory("target_course"),
            "quais universidades eu quero": self._memory("target_universities"),
            "quais sao minhas notas do enem": self._memory("enem_scores"),
            "meu objetivo e engenharia de software na ufpr, utfpr e pucpr": {
                "intent": "save_memory",
                "domain": "academic",
                "confidence": 0.92,
                "should_execute": False,
                "should_search": False,
                "action_type": "",
                "target": "",
                "query": "",
                "entities": {
                    "target_course": "Engenharia de Software",
                    "target_universities": ["UFPR", "UTFPR", "PUCPR"],
                },
                "answer_hint": "Salvar objetivo academico",
            },
            "quero fazer engenharia de software na utfpr": {
                "intent": "save_memory",
                "domain": "academic",
                "confidence": 0.92,
                "should_execute": False,
                "should_search": False,
                "action_type": "",
                "target": "",
                "query": "",
                "entities": {
                    "target_course": "Engenharia de Software",
                    "target_universities": ["UTFPR"],
                },
                "answer_hint": "Salvar objetivo academico",
            },
            "pode pesquisar sem minha ordem, guarda isso": {
                "intent": "update_preference",
                "domain": "system",
                "confidence": 0.9,
                "should_execute": False,
                "should_search": False,
                "action_type": "",
                "target": "",
                "query": "",
                "entities": {"allow_auto_search": True},
                "answer_hint": "Atualizar preferencia",
            },
            "me fala as notas de corte sem pesquisar": self._chat("academic", "Explicar limitação sem pesquisar"),
        }

        return json.dumps(responses.get(normalized, self._chat()))

    def _chat(self, domain: str = "general", hint: str = "") -> dict:
        return {
            "intent": "chat",
            "domain": domain,
            "confidence": 0.9,
            "should_execute": False,
            "should_search": False,
            "action_type": "",
            "target": "",
            "query": "",
            "entities": {},
            "answer_hint": hint,
        }

    def _action(self, intent: str, domain: str, action_type: str, target: str) -> dict:
        return {
            "intent": intent,
            "domain": domain,
            "confidence": 0.95,
            "should_execute": True,
            "should_search": False,
            "action_type": action_type,
            "target": target,
            "query": "",
            "entities": {},
            "answer_hint": "",
        }

    def _search(self, target: str, query: str) -> dict:
        return {
            "intent": "search_web",
            "domain": "web",
            "confidence": 0.95,
            "should_execute": True,
            "should_search": True,
            "action_type": "search_website",
            "target": target,
            "query": query,
            "entities": {},
            "answer_hint": "",
        }

    def _memory(self, memory_key: str) -> dict:
        return {
            "intent": "ask_memory",
            "domain": "academic",
            "confidence": 0.9,
            "should_execute": False,
            "should_search": False,
            "action_type": "",
            "target": "",
            "query": "",
            "entities": {"memory_key": memory_key},
            "answer_hint": "Consultar memória",
        }

    def _multi(self, items: list[dict]) -> dict:
        return {
            "intent": "execute_action",
            "domain": "system",
            "confidence": 0.95,
            "should_execute": True,
            "should_search": any(item.get("type") == "search_website" for item in items),
            "action_type": "multi_action",
            "target": "",
            "query": "",
            "entities": {"items": items},
            "answer_hint": "",
        }


class FakeRouter:
    def __init__(self):
        self.actions = []

    def execute(self, decision: dict) -> Observation:
        self.actions.append(decision)

        if decision.get("type") == "multi_action":
            return Observation(True, " | ".join(item.get("type", "") for item in decision.get("items", [])))

        if decision.get("type") == "search_website":
            return Observation(True, f"Pesquisando {decision.get('query')} em {decision.get('target')}")

        return Observation(True, f"Executado {decision.get('type')} {decision.get('target', '')}".strip())


@dataclass
class TestCase:
    user_input: str
    expected_action_type: str = ""
    expected_contains: str = ""
    should_execute: bool = False


def build_assistant() -> tuple[Assistant, FakeRouter]:
    memory = TestMemory()
    store = InMemoryMemoryStore()
    seed_memory(store)
    router = FakeRouter()
    agent = Agent(FakeChatClient(), memory)
    interpreter = IntentInterpreter(FakeIntentClient(), memory, store)
    assistant = Assistant(
        agent=agent,
        router=router,
        memory=memory,
        mode_manager=ModeManager(),
        memory_store=store,
        context_engine=None,
        conversation_guard=ConversationGuard(store),
        intent_interpreter=interpreter,
    )
    return assistant, router


def seed_memory(store: InMemoryMemoryStore):
    store.save_long_memory("academic_goal", "target_course", "Engenharia de Software", importance=4)
    store.save_long_memory("academic_goal", "target_universities", "UFPR, UTFPR, PUCPR", importance=4)
    store.save_long_memory("enem", "last_score", "620", importance=4)
    store.save_long_memory("enem_area_scores", "matematica", "693", importance=4)
    store.save_long_memory("enem_area_scores", "linguagens", "584", importance=4)
    store.save_long_memory("enem_area_scores", "humanas", "561", importance=4)
    store.save_long_memory("enem_area_scores", "natureza", "593", importance=4)
    store.save_long_memory("enem_area_scores", "redacao", "600", importance=4)


TEST_CASES = [
    TestCase("abre o google", "open_website", "abrindo", True),
    TestCase("abre o youtube", "open_website", "abrindo", True),
    TestCase("abre a pasta downloads", "open_folder", "downloads", True),
    TestCase("pesquisa no youtube aula de python", "search_website", "pesquisar aula de python", True),
    TestCase("fecha o spotify", "close_app", "fechando", True),
    TestCase("abre o vscode", "open_app", "abrindo", True),
    TestCase("não é para pesquisar", "", "Não vou pesquisar", False),
    TestCase("me fala você em vez de pesquisar", "", "sem pesquisar", False),
    TestCase("por que você está pesquisando sem minha autorização?", "", "Não vou pesquisar", False),
    TestCase("não abra nada", "", "Não vou executar", False),
    TestCase("eles estavam falando sobre abrir o google, eu não entendi", "", "não vou abrir nada", False),
    TestCase("não entendi o que significa abrir o google", "", "não vou abrir nada", False),
    TestCase("como abre o google?", "", "ação apareceu como assunto", False),
    TestCase("não abre nada", "", "Não vou executar", False),
    TestCase("abre isso", "", "não ficou claro", False),
    TestCase("fecha ele", "", "qual aplicativo", False),
    TestCase("pesquisa aquilo", "", "o que você quer pesquisar", False),
    TestCase("eu estava pensando em pesquisar python", "", "pedido claro", False),
    TestCase("abre o google e pesquisa python", "multi_action", "executei as ações", True),
    TestCase("abre isso e fecha ele", "", "sequência", False),
    TestCase("o que é Power BI?", "", "Entendi", False),
    TestCase("como eu melhoro meu inglês?", "", "Entendi", False),
    TestCase("qual é a população do brasil?", "", "população do Brasil", False),
    TestCase("o que eu preciso estudar para melhorar minhas notas?", "", "priorizaria", False),
    TestCase("qual curso eu quero fazer?", "", "Engenharia de Software", False),
    TestCase("quais universidades eu quero?", "", "UFPR, UTFPR e PUCPR", False),
    TestCase("quais são minhas notas do enem?", "", "Matemática e suas Tecnologias: 693", False),
    TestCase("meu objetivo é engenharia de software na ufpr, utfpr e pucpr", "", "Registrei Engenharia de Software", False),
    TestCase("quero fazer engenharia de software na UTFPR", "", "Registrei Engenharia de Software", False),
    TestCase("pode pesquisar sem minha ordem, guarda isso", "", "Registrei essa preferência", False),
    TestCase("me fala as notas de corte sem pesquisar", "", "não consigo garantir as notas de corte reais", False),
    TestCase("qual é meu nome?", "", "Ainda não sei seu nome", False),
    TestCase("qual é o seu nome?", "", "OrionXT", False),
]


def run_case(case: TestCase):
    assistant, router = build_assistant()
    response = assistant.handle(case.user_input)
    executed = bool(router.actions)
    action_type = router.actions[-1].get("type", "") if router.actions else ""

    success = True
    error = "success"

    if executed != case.should_execute:
        success = False
        error = "execution_mismatch"

    if case.expected_action_type and action_type != case.expected_action_type:
        success = False
        error = "wrong_action_type"

    if case.expected_contains and case.expected_contains.lower() not in response.lower():
        success = False
        error = "wrong_response"

    print(f"[TESTE] {case.user_input}")
    print(f"Resposta: {response}")
    print(f"Executou ação: {executed}")
    print(f"Tipo de ação: {action_type or '-'}")
    print(f"STATUS: {'SUCESSO' if success else 'ERRO'}")
    print(f"TIPO DE ERRO: {error}")
    print("-" * 40)

    return success


if __name__ == "__main__":
    results = [run_case(case) for case in TEST_CASES]
    success_count = sum(1 for result in results if result)
    total = len(results)

    print("RESUMO:")
    print(f"Total: {total}")
    print(f"Sucesso: {success_count}")
    print(f"Erro: {total - success_count}")
    print(f"Taxa de acerto: {int((success_count / total) * 100)}%")

    raise SystemExit(0 if success_count == total else 1)
