from pathlib import Path
import sys


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.conversation_guard import ConversationGuard


if __name__ == "__main__":
    guard = ConversationGuard()

    blocked = [
        "não é para pesquisar porra",
        "por que você está pesquisando sem minha autorização?",
        "não execute isso",
        "não abra o google",
    ]

    allowed = [
        "quais foram minhas notas no enem?",
        "qual curso eu quero fazer?",
        "eles estavam falando sobre abrir o google, eu não entendi",
        "me fala você em vez de pesquisar",
        "me fala as notas de corte sem pesquisar",
    ]

    for text in blocked:
        response = guard.handle(text)
        assert response, f"ConversationGuard deveria bloquear: {text}"
        print("BLOQUEADO:", text)
        print("ORION:", response)
        print("-" * 40)

    for text in allowed:
        response = guard.handle(text)
        assert response is None, f"ConversationGuard nao deveria decidir dominio: {text}"
        print("PASSOU PARA IA:", text)
        print("-" * 40)

    print("SUCESSO: ConversationGuard ficou pequeno e seguro.")
