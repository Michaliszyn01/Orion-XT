from pathlib import Path
import json
import re
import sys


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.intent_interpreter import IntentInterpreter
from core.utils import normalize_text


class FakeClient:
    def generate(self, prompt: str) -> str:
        match = re.search(r"Mensagem do usuário:\s*(.+)\s*$", prompt, re.DOTALL)
        text = match.group(1).strip() if match else ""
        normalized = normalize_text(text).strip(" .?!,;:-")

        responses = {
            "abre o google": {
                "intent": "execute_action",
                "domain": "web",
                "confidence": 0.95,
                "should_execute": True,
                "should_search": False,
                "action_type": "open_website",
                "target": "google",
                "query": "",
                "entities": {},
                "answer_hint": "Abrir Google",
            },
            "eles estavam falando sobre abrir o google, eu nao entendi": {
                "intent": "chat",
                "domain": "general",
                "confidence": 0.9,
                "should_execute": False,
                "should_search": False,
                "action_type": "",
                "target": "",
                "query": "",
                "entities": {},
                "answer_hint": "Explicar sem abrir nada",
            },
            "nao e para pesquisar": {
                "intent": "chat",
                "domain": "system",
                "confidence": 0.95,
                "should_execute": False,
                "should_search": False,
                "action_type": "",
                "target": "",
                "query": "",
                "entities": {},
                "answer_hint": "Confirmar que nao vai pesquisar",
            },
            "me fala voce em vez de pesquisar": {
                "intent": "chat",
                "domain": "system",
                "confidence": 0.9,
                "should_execute": False,
                "should_search": False,
                "action_type": "",
                "target": "",
                "query": "",
                "entities": {},
                "answer_hint": "Responder sem pesquisar",
            },
            "qual curso eu quero fazer": {
                "intent": "ask_memory",
                "domain": "academic",
                "confidence": 0.9,
                "should_execute": False,
                "should_search": False,
                "action_type": "",
                "target": "",
                "query": "",
                "entities": {"memory_key": "target_course"},
                "answer_hint": "Responder curso alvo salvo",
            },
            "quais sao minhas notas do enem": {
                "intent": "ask_memory",
                "domain": "academic",
                "confidence": 0.9,
                "should_execute": False,
                "should_search": False,
                "action_type": "",
                "target": "",
                "query": "",
                "entities": {"memory_key": "enem_scores"},
                "answer_hint": "Responder notas salvas",
            },
            "o que eu preciso estudar para melhorar minhas notas": {
                "intent": "study_strategy",
                "domain": "academic",
                "confidence": 0.9,
                "should_execute": False,
                "should_search": False,
                "action_type": "",
                "target": "",
                "query": "",
                "entities": {},
                "answer_hint": "Gerar estrategia com notas salvas",
            },
            "meu objetivo e engenharia de software na ufpr, utfpr e pucpr": {
                "intent": "save_memory",
                "domain": "academic",
                "confidence": 0.9,
                "should_execute": False,
                "should_search": False,
                "action_type": "",
                "target": "",
                "query": "",
                "entities": {
                    "target_course": "Engenharia de Software",
                    "target_universities": ["UFPR", "UTFPR", "PUCPR"],
                },
                "answer_hint": "Salvar objetivo academico",
            },
            "pode pesquisar sem minha ordem": {
                "intent": "update_preference",
                "domain": "system",
                "confidence": 0.9,
                "should_execute": False,
                "should_search": False,
                "action_type": "",
                "target": "",
                "query": "",
                "entities": {"allow_auto_search": True},
                "answer_hint": "Atualizar preferencia",
            },
            "qual e a populacao do brasil": {
                "intent": "chat",
                "domain": "general",
                "confidence": 0.85,
                "should_execute": False,
                "should_search": False,
                "action_type": "",
                "target": "",
                "query": "",
                "entities": {},
                "answer_hint": "Responder com limitacao de dados atuais",
            },
            "pesquisa no youtube aula de python": {
                "intent": "search_web",
                "domain": "web",
                "confidence": 0.95,
                "should_execute": True,
                "should_search": True,
                "action_type": "search_website",
                "target": "youtube",
                "query": "aula de python",
                "entities": {},
                "answer_hint": "Pesquisar aula de python",
            },
        }

        return json.dumps(responses.get(normalized, {"intent": "clarify", "confidence": 0.1}))


TESTS = [
    {
        "input": "abre o google",
        "expected_intent": "execute_action",
        "expected_action_type": "open_website",
        "expected_target": "google",
        "should_execute": True,
    },
    {
        "input": "eles estavam falando sobre abrir o google, eu não entendi",
        "expected_intent": "chat",
        "should_execute": False,
    },
    {
        "input": "não é para pesquisar",
        "expected_intent": "chat",
        "should_search": False,
    },
    {
        "input": "me fala você em vez de pesquisar",
        "expected_intent": "chat",
        "should_search": False,
    },
    {
        "input": "qual curso eu quero fazer?",
        "expected_intent": "ask_memory",
        "expected_domain": "academic",
    },
    {
        "input": "quais são minhas notas do enem?",
        "expected_intent": "ask_memory",
        "expected_domain": "academic",
    },
    {
        "input": "o que eu preciso estudar para melhorar minhas notas?",
        "expected_intent": "study_strategy",
        "expected_domain": "academic",
    },
    {
        "input": "meu objetivo é engenharia de software na ufpr, utfpr e pucpr",
        "expected_intent": "save_memory",
        "expected_domain": "academic",
    },
    {
        "input": "pode pesquisar sem minha ordem",
        "expected_intent": "update_preference",
    },
    {
        "input": "qual é a população do brasil?",
        "expected_intent": "chat",
        "should_search": False,
    },
    {
        "input": "pesquisa no youtube aula de python",
        "expected_intent": "search_web",
        "expected_action_type": "search_website",
        "expected_target": "youtube",
        "should_search": True,
    },
]


if __name__ == "__main__":
    interpreter = IntentInterpreter(FakeClient())

    for case in TESTS:
        result = interpreter.interpret(case["input"])
        print("USER:", case["input"])
        print("INTENT:", result)

        assert result["intent"] == case["expected_intent"], (case, result)

        if "expected_domain" in case:
            assert result["domain"] == case["expected_domain"], (case, result)

        if "expected_action_type" in case:
            assert result["action_type"] == case["expected_action_type"], (case, result)

        if "expected_target" in case:
            assert result["target"] == case["expected_target"], (case, result)

        if "should_execute" in case:
            assert result["should_execute"] is case["should_execute"], (case, result)

        if "should_search" in case:
            assert result["should_search"] is case["should_search"], (case, result)

        print("STATUS: SUCESSO")
        print("-" * 40)

    print("SUCESSO: IntentInterpreter retornou intenções seguras.")
