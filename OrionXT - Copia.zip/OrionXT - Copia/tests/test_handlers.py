from pathlib import Path
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.handlers.mode_handler import ModeHandler
from core.handlers.memory_handler import MemoryHandler
from core.handlers.name_handler import NameHandler
from core.handlers.study_handler import StudyHandler
from core.modes import ModeManager
from fakes import InMemoryMemoryStore


class FakeMemory:
    def __init__(self):
        self.name = ""
        self.data = {"preferences": {}, "history": []}

    def set_name(self, name: str):
        self.name = name

    def get_name(self):
        return self.name

    def save(self):
        pass


TESTS = []


def run_name_flow() -> bool:
    memory = FakeMemory()
    handler = NameHandler(memory)
    responses = [
        handler.handle("meu nome é Marcos"),
        handler.handle("qual é meu nome?"),
        handler.handle("qual é seu nome?"),
    ]
    success = (
        responses[0] == "Entendido. Vou te chamar de Marcos."
        and responses[1] == "Seu nome é Marcos."
        and responses[2] == "Meu nome é OrionXT. Sou seu assistente pessoal."
    )

    print("[TESTE] fluxo de nome")
    for response in responses:
        print(f"Resposta: {response}")
    print(f"STATUS: {'SUCESSO' if success else 'ERRO'}")
    print(f"TIPO DE ERRO: {'success' if success else 'wrong_response'}")
    print("-" * 40)
    return success


def run_mode_flow() -> bool:
    opened = []
    mode_manager = ModeManager()
    handler = ModeHandler(mode_manager, opener=opened.append)
    activate_response = handler.handle("ativa modo Orion")
    active_mode = mode_manager.current_mode
    deactivate_response = handler.handle("desativar modo Orion")
    inactive_mode = mode_manager.current_mode

    success = (
        activate_response == "Modo Orion ativado. Estou online e pronto para operar."
        and active_mode == "orion"
        and len(opened) == 1
        and deactivate_response == "Modo Orion desativado. Voltando ao modo normal."
        and inactive_mode == "normal"
    )

    print("[TESTE] fluxo modo Orion")
    print(f"Ativar: {activate_response}")
    print(f"Desativar: {deactivate_response}")
    print(f"Tema aberto: {len(opened)}")
    print(f"STATUS: {'SUCESSO' if success else 'ERRO'}")
    print(f"TIPO DE ERRO: {'success' if success else 'wrong_response'}")
    print("-" * 40)
    return success


def seed_academic_memory(store: InMemoryMemoryStore):
    store.save_long_memory("academic_goal", "target_course", "Engenharia de Software", importance=4)
    store.save_long_memory("academic_goal", "target_universities", "UFPR, UTFPR, PUCPR", importance=4)
    store.save_long_memory("enem", "last_score", "620", importance=4)
    store.save_long_memory("enem_area_scores", "matematica", "693", importance=4)
    store.save_long_memory("enem_area_scores", "linguagens", "584", importance=4)
    store.save_long_memory("enem_area_scores", "humanas", "561", importance=4)
    store.save_long_memory("enem_area_scores", "natureza", "593", importance=4)
    store.save_long_memory("enem_area_scores", "redacao", "600", importance=4)


def run_memory_read_flow() -> bool:
    store = InMemoryMemoryStore()
    seed_academic_memory(store)
    handler = MemoryHandler(FakeMemory(), store)
    course_response = handler.handle_ask_memory({"entities": {"memory_key": "target_course"}})
    enem_response = handler.handle_ask_memory({"entities": {"memory_key": "enem_scores"}})

    success = (
        "Engenharia de Software" in course_response
        and "UFPR, UTFPR e PUCPR" in course_response
        and "Matemática e suas Tecnologias: 693" in enem_response
        and "Nota geral registrada: 620." in enem_response
    )

    print("[TESTE] leitura de memória acadêmica")
    print(f"Curso: {course_response}")
    print(f"ENEM: {enem_response}")
    print(f"STATUS: {'SUCESSO' if success else 'ERRO'}")
    print(f"TIPO DE ERRO: {'success' if success else 'wrong_response'}")
    print("-" * 40)
    return success


def run_memory_write_flow() -> bool:
    store = InMemoryMemoryStore()
    memory = FakeMemory()
    handler = MemoryHandler(memory, store)
    save_response = handler.handle_save_memory(
        {
            "entities": {
                "target_course": "engenharia software",
                "target_universities": "ufpr ou utfpr",
            }
        },
        user_input="quero fazer engenharia de software na UFPR ou UTFPR",
    )
    question_response = handler.handle_save_memory(
        {"entities": {"target_course": "Engenharia de Software"}},
        user_input="qual curso eu quero fazer?",
    )
    preference_response = handler.handle_update_preference(
        {"entities": {"allow_auto_search": True}}
    )

    success = (
        save_response == "Entendido. Registrei Engenharia de Software como curso alvo e UFPR e UTFPR como universidades alvo."
        and handler.get_memory_value("academic_goal", "target_course") == "Engenharia de Software"
        and handler.get_universities_value() == "UFPR, UTFPR"
        and question_response.startswith("Não vou salvar uma pergunta")
        and store.preferences.get("allow_auto_search") == "true"
        and memory.data["preferences"].get("allow_auto_search") == "true"
        and "Registrei essa preferência" in preference_response
    )

    print("[TESTE] escrita de memória acadêmica")
    print(f"Salvar: {save_response}")
    print(f"Pergunta: {question_response}")
    print(f"Preferência: {preference_response}")
    print(f"STATUS: {'SUCESSO' if success else 'ERRO'}")
    print(f"TIPO DE ERRO: {'success' if success else 'wrong_response'}")
    print("-" * 40)
    return success


def run_study_flow() -> bool:
    store = InMemoryMemoryStore()
    seed_academic_memory(store)
    memory_handler = MemoryHandler(FakeMemory(), store)
    study_handler = StudyHandler(memory_handler)
    response = study_handler.handle_study_strategy({"entities": {}})

    success = (
        "Matemática, Redação e Natureza" in response
        and "questões" in response
    )

    print("[TESTE] estratégia de estudo")
    print(f"Resposta: {response}")
    print(f"STATUS: {'SUCESSO' if success else 'ERRO'}")
    print(f"TIPO DE ERRO: {'success' if success else 'wrong_response'}")
    print("-" * 40)
    return success


if __name__ == "__main__":
    results = [
        run_name_flow(),
        run_mode_flow(),
        run_memory_read_flow(),
        run_memory_write_flow(),
        run_study_flow(),
    ]
    success_count = sum(1 for result in results if result)
    total = len(results)

    print("RESUMO:")
    print(f"Total: {total}")
    print(f"Sucesso: {success_count}")
    print(f"Erro: {total - success_count}")

    raise SystemExit(0 if success_count == total else 1)
