from pathlib import Path
import sys

import numpy as np


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from voice.stt import (
    LISTEN_STATUS_NO_SPEECH,
    LISTEN_STATUS_TOO_SHORT,
    LISTEN_STATUS_TRANSCRIBING,
    SpeechCaptureSession,
)


def audio_chunk(amplitude: int, frames: int = 1600):
    return np.full((frames, 1), amplitude, dtype=np.int16)


def build_session() -> SpeechCaptureSession:
    session = SpeechCaptureSession(
        samplerate=16000,
        silence_threshold=0.015,
        silence_duration=0.6,
        max_duration=12,
        min_recording_duration=0.35,
        pre_speech_timeout=5,
        min_voiced_duration=0.18,
        pre_speech_rollback=0.25,
    )
    session.capture_start = 0.0
    return session


def print_result(name: str, success: bool, error_type: str = "success"):
    print(f"[TESTE] {name}")
    print(f"STATUS: {'SUCESSO' if success else 'ERRO'}")
    print(f"TIPO DE ERRO: {error_type if not success else 'success'}")
    print("-" * 40)


def test_no_speech_timeout() -> bool:
    session = build_session()

    for index in range(10):
        session.process_audio(audio_chunk(0), now=index * 0.1)

    should_stop = session.should_stop(now=5.1)
    result, audio = session.build_result()
    success = should_stop and result.status == LISTEN_STATUS_NO_SPEECH and audio is None
    print_result("sem fala encerra sem transcrever", success, "no_speech_failed")
    return success


def test_short_noise_is_ignored() -> bool:
    session = build_session()
    session.process_audio(audio_chunk(1200, frames=800), now=0.1)
    session.process_audio(audio_chunk(0), now=0.2)
    session.process_audio(audio_chunk(0), now=0.4)
    session.process_audio(audio_chunk(0), now=0.7)
    session.process_audio(audio_chunk(0), now=0.9)

    should_stop = session.should_stop(now=0.9)
    result, audio = session.build_result()
    success = should_stop and result.status == LISTEN_STATUS_TOO_SHORT and audio is None
    print_result("ruído curto não vai para whisper", success, "short_noise_failed")
    return success


def test_short_pause_does_not_cut_phrase() -> bool:
    session = build_session()

    session.process_audio(audio_chunk(1400), now=0.1)
    session.process_audio(audio_chunk(1400), now=0.2)
    session.process_audio(audio_chunk(1400), now=0.3)
    session.process_audio(audio_chunk(0), now=0.4)

    not_cut = not session.should_stop(now=0.85)

    session.process_audio(audio_chunk(1400), now=0.9)
    session.process_audio(audio_chunk(0), now=1.0)
    session.process_audio(audio_chunk(0), now=1.65)

    stopped_after_real_silence = session.should_stop(now=1.65)
    result, audio = session.build_result()
    success = (
        not_cut
        and stopped_after_real_silence
        and result.status == LISTEN_STATUS_TRANSCRIBING
        and audio is not None
    )
    print_result("pausa curta não corta frase", success, "pause_cut_failed")
    return success


if __name__ == "__main__":
    results = [
        test_no_speech_timeout(),
        test_short_noise_is_ignored(),
        test_short_pause_does_not_cut_phrase(),
    ]
    success_count = sum(1 for result in results if result)
    total = len(results)

    print("RESUMO:")
    print(f"Total: {total}")
    print(f"Sucesso: {success_count}")
    print(f"Erro: {total - success_count}")

    raise SystemExit(0 if success_count == total else 1)
