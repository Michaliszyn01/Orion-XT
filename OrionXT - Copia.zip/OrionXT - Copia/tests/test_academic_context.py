from pathlib import Path
import sys


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from storage.database import Database
from storage.memory_store import MemoryStore
from core.context_engine import ContextEngine


if __name__ == "__main__":
    db = Database("data/test_academic_context.sqlite3")
    store = MemoryStore(db)
    engine = ContextEngine(store)

    tests = [
        "tirei 620 no enem",
        "minha nota em matemática foi 693",
        "minha nota em linguagens códigos e suas tecnologias foi 584",
        "minha nota em ciências humanas e suas tecnologias foi 561",
        "minha nota em ciências da natureza e suas tecnologias foi 593",
        "em redação foi 600",
        "quais são as minhas notas does nem?",
        "quais foram as minhas notas nem nem?",
        "você não salvou minhas notas?",
    ]

    for text in tests:
        print("USER:", text)
        print("ORION:", engine.handle(text))
        print("-" * 40)

    engine2 = ContextEngine(store)
    print("PERSISTENCIA:")
    print("ORION:", engine2.handle("quais foram minhas notas nem nem?"))
