from pathlib import Path
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.observation import Observation
from core.response_generator import ResponseGenerator


class FakeClient:
    def __init__(self, response: str):
        self.response = response
        self.calls = 0

    def generate(self, prompt: str) -> str:
        self.calls += 1
        return self.response


TESTS = [
    {
        "name": "fallback sem llm para acao",
        "generator": ResponseGenerator(),
        "kwargs": {
            "user_input": "abre o google",
            "decision": {"type": "open_website", "target": "google"},
            "observation": Observation(True, "Abrindo https://www.google.com"),
            "success": True,
        },
        "expected_contains": "abrindo o Google",
        "forbidden_contains": "",
    },
    {
        "name": "llm seguro pode naturalizar",
        "generator": ResponseGenerator(FakeClient("Pronto, abri o Google.")),
        "kwargs": {
            "user_input": "abre o google",
            "decision": {"type": "open_website", "target": "google"},
            "observation": Observation(True, "Abrindo https://www.google.com"),
            "success": True,
        },
        "expected_contains": "abri o Google",
        "forbidden_contains": "",
    },
    {
        "name": "erro nao pode virar sucesso inventado",
        "generator": ResponseGenerator(FakeClient("Pronto, abri o Spotify.")),
        "kwargs": {
            "user_input": "abre o spotify",
            "decision": {"type": "open_app", "target": "spotify"},
            "observation": Observation(False, "Nenhum caminho configurado para 'spotify' foi encontrado neste PC."),
        },
        "expected_contains": "Não consegui",
        "forbidden_contains": "abri o Spotify",
    },
    {
        "name": "sucesso pode ser inferido da observacao",
        "generator": ResponseGenerator(),
        "kwargs": {
            "user_input": "fecha o spotify",
            "decision": {"type": "close_app", "target": "spotify"},
            "observation": Observation(True, "Fechando spotify."),
        },
        "expected_contains": "fechando o Spotify",
        "forbidden_contains": "",
    },
    {
        "name": "bloqueio de seguranca preserva firmeza",
        "generator": ResponseGenerator(FakeClient("Beleza, vou abrir mesmo assim.")),
        "kwargs": {
            "user_input": "não abra o google",
            "interpretation": {"intent": "chat", "domain": "system"},
            "response_type": "blocked",
            "success": False,
            "fallback": "Entendido. Não vou abrir nada.",
        },
        "expected_contains": "Não vou",
        "forbidden_contains": "abrir mesmo assim",
    },
]


def run_case(case: dict) -> bool:
    response = case["generator"].generate(**case["kwargs"])
    expected = case["expected_contains"].lower()
    forbidden = case["forbidden_contains"].lower()
    success = expected in response.lower() and (not forbidden or forbidden not in response.lower())
    error = "success" if success else "wrong_response"

    print(f"[TESTE] {case['name']}")
    print(f"Resposta: {response}")
    print(f"STATUS: {'SUCESSO' if success else 'ERRO'}")
    print(f"TIPO DE ERRO: {error}")
    print("-" * 40)

    return success


def run_boundary_check() -> bool:
    generator = ResponseGenerator()
    forbidden_attrs = ["router", "validator", "open_app", "close_app", "open_folder", "search_website"]
    found = [name for name in forbidden_attrs if hasattr(generator, name)]
    success = not found
    error = "success" if success else f"forbidden_attrs:{found}"

    print("[TESTE] sem acesso a executor")
    print(f"Atributos proibidos encontrados: {found or '-'}")
    print(f"STATUS: {'SUCESSO' if success else 'ERRO'}")
    print(f"TIPO DE ERRO: {error}")
    print("-" * 40)

    return success


if __name__ == "__main__":
    results = [run_case(case) for case in TESTS]
    results.append(run_boundary_check())

    success_count = sum(1 for result in results if result)
    total = len(results)

    print("RESUMO:")
    print(f"Total: {total}")
    print(f"Sucesso: {success_count}")
    print(f"Erro: {total - success_count}")

    raise SystemExit(0 if success_count == total else 1)
