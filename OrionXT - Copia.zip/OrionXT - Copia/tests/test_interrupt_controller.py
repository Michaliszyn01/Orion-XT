from pathlib import Path
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.interrupt_controller import InterruptController
from voice import tts


def print_result(name: str, success: bool, error_type: str = "success"):
    print(f"[TESTE] {name}")
    print(f"STATUS: {'SUCESSO' if success else 'ERRO'}")
    print(f"TIPO DE ERRO: {error_type if not success else 'success'}")
    print("-" * 40)


def test_controller_interrupts_active_speech() -> bool:
    calls = []
    controller = InterruptController()
    controller.register_tts_handlers(
        stop_current_speech=lambda: calls.append("stop") or True,
        clear_speech_queue=lambda: calls.append("clear") or 3,
    )
    controller.set_speaking(True)
    interrupted = controller.request_interrupt()
    success = interrupted and controller.is_interrupted() and calls == ["clear", "stop"]
    controller.clear_interrupt()
    success = success and not controller.is_interrupted()
    print_result("controller interrompe fala ativa", success, "state_mismatch")
    return success


def test_controller_ignores_idle_interrupt() -> bool:
    controller = InterruptController()
    interrupted = controller.request_interrupt()
    success = interrupted is False and controller.is_interrupted()
    controller.clear_interrupt()
    success = success and not controller.is_interrupted()
    print_result("controller sem fala ativa", success, "idle_interrupt_failed")
    return success


def test_tts_replaces_pending_speech() -> bool:
    original_ensure_worker = tts._ensure_worker
    tts._ensure_worker = lambda: None

    try:
        tts.stop_speech()
        tts.interrupt_controller.clear_interrupt()

        tts.speak("Primeira resposta longa. " * 80)
        first_items = list(tts._speech_queue.queue)
        first_generation = first_items[0][0] if first_items else None

        tts.speak("Segunda resposta curta.")
        second_items = list(tts._speech_queue.queue)

        success = (
            bool(first_items)
            and bool(second_items)
            and all("Segunda resposta curta" in item[1] for item in second_items)
            and all(item[0] != first_generation for item in second_items)
        )

        stopped = tts.stop_speech()
        success = success and stopped and tts._speech_queue.empty()
    finally:
        tts._ensure_worker = original_ensure_worker
        tts.stop_speech()
        tts.interrupt_controller.clear_interrupt()

    print_result("tts substitui fala pendente", success, "queue_not_replaced")
    return success


def test_tts_idle_stop_is_safe() -> bool:
    tts.stop_speech()
    tts.interrupt_controller.clear_interrupt()
    stopped = tts.stop_speech()
    success = stopped is False
    tts.interrupt_controller.clear_interrupt()
    print_result("tts interrompe sem fala", success, "idle_stop_failed")
    return success


if __name__ == "__main__":
    results = [
        test_controller_interrupts_active_speech(),
        test_controller_ignores_idle_interrupt(),
        test_tts_replaces_pending_speech(),
        test_tts_idle_stop_is_safe(),
    ]
    success_count = sum(1 for result in results if result)
    total = len(results)

    print("RESUMO:")
    print(f"Total: {total}")
    print(f"Sucesso: {success_count}")
    print(f"Erro: {total - success_count}")

    raise SystemExit(0 if success_count == total else 1)
