import os
import time

import requests


class OllamaClient:
    def __init__(
        self,
        model: str | None = None,
        base_url: str | None = None,
        timeout: float | None = None,
        max_retries: int | None = None,
    ):
        self.model = model or os.getenv("ORION_OLLAMA_MODEL") or "gemma3:4b"
        self.base_url = (base_url or os.getenv("ORION_OLLAMA_BASE_URL") or "http://localhost:11434").rstrip("/")
        self.timeout = self._float_setting("ORION_OLLAMA_TIMEOUT", timeout, 120.0)
        self.max_retries = self._int_setting("ORION_OLLAMA_MAX_RETRIES", max_retries, 1)

    def generate(self, prompt: str) -> str:
        attempts = self.max_retries + 1
        last_error = ""

        for attempt in range(attempts):
            try:
                response = requests.post(
                    f"{self.base_url}/api/generate",
                    json={
                        "model": self.model,
                        "prompt": prompt,
                        "stream": False
                    },
                    timeout=self.timeout
                )
                response.raise_for_status()
                data = response.json()

                if not isinstance(data, dict):
                    return "Erro ao falar com o Ollama: resposta invalida da API."

                return data.get("response", "").strip()
            except requests.Timeout as exc:
                last_error = f"timeout apos {self.timeout}s: {exc}"
            except requests.RequestException as exc:
                last_error = str(exc)
            except ValueError as exc:
                last_error = f"resposta JSON invalida: {exc}"

            if attempt < attempts - 1:
                time.sleep(min(2.0, 0.3 * (attempt + 1)))

        return (
            "Erro ao falar com o Ollama "
            f"(url={self.base_url}, modelo={self.model}, tentativas={attempts}, "
            f"timeout={self.timeout}s): {last_error}"
        )

    def _float_setting(self, env_name: str, explicit_value: float | None, default: float) -> float:
        value = explicit_value if explicit_value is not None else os.getenv(env_name)

        try:
            parsed = float(value)
        except (TypeError, ValueError):
            return default

        return parsed if parsed > 0 else default

    def _int_setting(self, env_name: str, explicit_value: int | None, default: int) -> int:
        value = explicit_value if explicit_value is not None else os.getenv(env_name)

        try:
            parsed = int(value)
        except (TypeError, ValueError):
            return default

        return max(0, parsed)
